<?php 
	session_start();
	if(!isset($_SESSION["SId"]))
	{
		header("location:login.php?requestUrl=corder.php?".$_SERVER['QUERY_STRING']);
	}
	
	mysql_connect("localhost","root","") or die("Error: Connection problem");
	mysql_select_db("canteen") or die("Error: No Databse found :-: canteen");

	if(isset($_GET["del"]))
	{
		
		$str = "DELETE FROM tbl_orderitem WHERE OIId='".$_GET["del"]."'";
		
		mysql_query($str) or die("Error: Insert query problem");
		
		echo '<script type="text/javascript"> alert("Item Removed from Cart successfully"); document.location.href="cartorder.php"; </script>';
	}
?>	
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Nirma Canteen | Home</title>

    <!-- Favicon -->
    <?php include("headerscript.php"); ?>
    <script type="text/javascript">
	$(document).ready(function(e) {
        $("#quantity").blur(function(e) {
            var qty = $(this).val();
			$("#tamount").val(parseFloat(qty)*parseFloat($("#amount").val()));
        });
    });

</script>
<script type="text/javascript">
	function confirmme()
		{
			if(confirm("Confirm Your Order"))
			{
				return true;
			}
			return false;
			
		}
	</script>
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
<?php include("header.php"); ?>
    <section id="mu-reservation" style="padding-top:150px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-reservation-area">
            <div class="mu-title">
              <span class="mu-subtitle">Customer Order</span>
              <h2>Detail</h2>
              <i class="fa fa-spoon"></i>              
              <span class="mu-title-bar"></span>
            </div>
            
            <div class="mu-reservation-content">
               							<?php 
										$str1234 = "SELECT T.*,F.FoodName,F.Amount FROM tbl_orderitem as T INNER JOIN tbl_foodmenu as F ON F.FoodId=T.FoodId WHERE T.UserId='".$_SESSION["SId"]."' AND T.Orderid='0'";
										$FCards = mysql_query($str1234) or die("Error: Select Query problem");
										$num = mysql_num_rows($FCards);
										if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													 <th>Items Name</th>
													<th>Quantity</th>
                                                    <th>Price</th>
                                                    <th>Total Amount</th>
												</tr>
												</thead>
												<tbody>
												<?php
												$GTotal = 0;
												 while($Rows = mysql_fetch_array($FCards))
												{
													$GTotal += $Rows["TotalAmount"];
												?>
												<tr>
													<td class="td-actions"><a href="?del=<?php echo $Rows["OIId"]; ?>" class="btn btn-small" onClick="return confirmme('Are you sure to Delete : <?php echo $Rows["FoodName"]; ?> ?')"><img src="assets/trash.png" /></a></td>
													<td><?php echo $Rows["FoodName"]; ?></td>
													<td><?php echo $Rows["Quantity"]; ?></td>
													
                                                    <td><?php echo $Rows["Amount"]; ?></td>
													<td><?php echo $Rows["TotalAmount"]; ?></td>
												</tr>
												<?php } ?>
                                                <tr>
                                                	<th style="background:rgba(204, 153, 102, 0.49)" colspan="4" align="right">Grand Total</th>
                                                    <th style="background:rgba(204, 153, 102, 0.49)"><?php printf("%.2f",$GTotal); ?></th>
                                                </tr>
												</tbody>
											</table>    
                                            <a href="payment.php" style="float:right;" class="btn btn-success btn-small" onClick="return confirmme('Are you sure to Order')">Pay &amp; Order Now >></a>
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Cart</div>
                                        <?php } ?>
                  
            <!--<div class="mu-restaurant-menu-content">
              <ul class="nav nav-tabs mu-restaurant-menu">
                <li class="active"><a href="#breakfast" data-toggle="tab">Breakfast</a></li>
                <li><a href="#meals" data-toggle="tab">Meals</a></li>
                <li><a href="#snacks" data-toggle="tab">Snacks</a></li>
                <li><a href="#desserts" data-toggle="tab">Desserts</a></li>
                <li><a href="#drinks" data-toggle="tab">Drinks</a></li>
              </ul>
            </div>-->
          </div>
         
        </div>
      </div>
    </div>
  </div>
</div>
</section>
    <?php include("footer.php"); ?>

  </body>
  
</html>