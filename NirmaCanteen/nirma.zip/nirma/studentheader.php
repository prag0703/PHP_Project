<header id="mu-header" >   
    <nav class="navbar navbar-default mu-main-navbar" role="navigation" style="background-color=#000;" >  
      <div class="container">
         <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->                                                        
         <a class="navbar-brand" href="index.html" style="color : #c96; width : 250px; font-size:25px; padding-top:14px; color:#c1a35f;">NIRMA CANTEEN </a> 
        
        </div>
        <?php if(isset($_SESSION["emailId"])) { ?>
         <?php
			$str12 = "SELECT Amount FROM tblwallet WHERE UserId='".$_SESSION["emailId"]."'";
			$FData12 = mysql_query($str12) or die("Error: Select Query problem");
			$numRec12 = mysql_num_rows($FData12);
			$TAmount = "0.00";
			if($numRec12>0)
			{
				$DataR = mysql_fetch_assoc($FData12);
				$TAmount = $DataR["Amount"];
			}
		?>
        <div style="position: fixed; top: 8px; left: 9%; color: #c96;">Welcome <?php echo $_SESSION["fname"]; ?> [<?php echo $_SESSION["emailId"]; ?>] :: Rs. <?php echo $TAmount; ?></div>
        <div style="position:fixed; right:10%; top:0px; background:#999;"><a href="cartorder.php" style="display:block; padding:8px; color:#FFF;">CART [5] : Rs. 120</a></div>
       <?php } ?>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right mu-main-nav">
            <li><a href="index.php#mu-slider">HOME</a></li>
            <li><a href="index.php#mu-about-us">ABOUT US</a></li>                       
            <li><a href="index.php#mu-restaurant-menu">MENU</a></li>                       
            <!-- <li><a href="#mu-reservation">RESERVATION</a></li>  -->                     
            <li><a href="index.php#mu-gallery">GALLERY</a></li>
            <li><a href="index.php#mu-chef">OUR TEAM</a></li>
            <!-- <li><a href="#mu-latest-news">BLOG</a></li> -->
            <li><a href="index.php#mu-contact">CONTACT</a></li> 
            <?php if(isset($_SESSION["SId"])) {?>
            <li><a href="logout.php">LOGOUT</a></li>
            <?php } else { ?>
             <li><a href="login.php">LOGIN</a></li>
             <?php } ?>
           <!--  <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="blog-archive.html">PAGE <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">                
                <li><a href="blog-archive.html">BLOG</a></li>
                <li><a href="blog-single.html">BLOG DETAILS</a></li>
                <li><a href="404.html">404 PAGE</a></li>                                            
              </ul>
            </li> -->
          </ul>                            
        </div><!--/.nav-collapse -->       
      </div>          
    </nav> 
  </header>
  