<?php
mysql_connect("localhost", "root" ,"")or die("error in connection");
    mysql_select_db("canteen")or die("Errron in select");
session_start();

  if(isset($_POST["submit"])) 
  {
    $Email = $_POST["email"];
    $password = $_POST["password"];
    $ApEmail = explode("@", $Email);
    if(strcasecmp($ApEmail[1], "nirmauni.ac.in")!=0)
    {
       header("location:login.php?msg=You are not Enter Proper EmailId."); 
    }
    else
    {
    
    

    $sec = "SELECT * FROM register where email = '$Email' AND pwd = '$password'";
    $Rdata = mysql_query($sec) or die("error in select");
    //echo mysql_num_rows($Rdata);
    //die;
    if(mysql_num_rows($Rdata)>0)
    {
		$Rows = mysql_fetch_assoc($Rdata);
		$_SESSION["SId"] = $Rows["sid"];
		$_SESSION["emailId"] = $Email;
		$_SESSION["Staff"] = 0; 
		$_SESSION["fname"] = $Rows["fname"]." ".$Rows["lname"];
		$IsAvail = 0;
		
	if($Email == "manager@nirmauni.ac.in")
    {
    	$_SESSION["Staff"] = 1;    
         header("location:userorder.php?msg=order sucessfully");
         die;
    }
		
      for($i=1;$i<10;$i++)
      {
        $valArr = explode($i, $Email);
        if(sizeof($valArr)>1)
        {
            $IsAvail = 1;
            break;
        }
      }
      
      if($IsAvail==1)
      {
		 header("location:index.php#mu-restaurant-menu");
        //echo "This is student";
      }
      else
      {
        header("location:index.php?msg=login sucessfully");
        //echo "This is proffessior";
      }
  }
  else
  {
    header("location:login.php?msg=Sorry, You are not found registered user."); 
  }
    die;
  }
    //header("location:corder.php");
	 session_start();
		 $_SESSION["SId"] = $Rows["SId"];
		$_SESSION["fname"] = $Rows["fname"];
  
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Nirma Canteen | Home</title>

    <!-- Favicon -->
    <?php include("headerscript.php"); ?>
    

  </head>
  <script>
function validateForm()
  {

  var email = document.forms["myForm"]["email"]; //name
   if(email.value == "")
  {
   alert("Please, Enter Email");
   email.focus();
   return false;
  }
}
  </script>
  <body>  
  
 
<?php include("header.php"); ?>

   

    <section id="mu-reservation" style="padding-top:150px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-reservation-area">
            <div class="mu-title">
              <span class="mu-subtitle">Make A</span>
              <h2>Login</h2>
              <i class="fa fa-spoon"></i>              
              <span class="mu-title-bar"></span>
            </div>
            <div class="mu-reservation-content">
              <p></p>
              <div class="row">
                  
                  <form method="post"  class="mu-reservation-form" action="" name="myform">
                    
                  <div class="col-md-12">
                    <div class="form-group">                        
                      <input type="email" class="form-control" required name="email" id="email" placeholder="Email">
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="form-group">                        
                      <input type="password" class="form-control" required name="password" id="password" placeholder="Password">
                    </div>
                  </div>

                 
                <div class="col-md-12">
                  <button type="submit" name="submit" class="mu-readmore-btn" > Login </button> <br>
                  <br>
                  Not Registe?&nbsp;<a href="signup.php" >Signup</a>
                </div>
              </form>      
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php include("footer.php"); ?>
</body>
</html>