<?php 
	session_start();
	if(!isset($_SESSION["SId"]))
	{
		header("location:login.php");
	}
	
	if($_SESSION["Staff"]!=1)
	{
		session_destroy();
		header("location:login.php");
	}
	
	mysql_connect("localhost","root","") or die("Error: Connection problem");
	mysql_select_db("canteen") or die("Error: No Databse found :-: canteen");

	if(isset($_GET["process"]))
	{
		
		$str = "UPDATE tbl_order SET IsConfirm='-1' WHERE OrderId='".$_GET["process"]."'";
		
		mysql_query($str) or die("Error: Insert query problem");
		
		echo '<script type="text/javascript"> alert("Order in Process..."); document.location.href="userorder.php"; </script>';
	}
	
	if(isset($_GET["complete"]))
	{
		
		$str = "UPDATE tbl_order SET IsConfirm='1' WHERE OrderId='".$_GET["complete"]."'";
		
		mysql_query($str) or die("Error: Insert query problem");
		
		echo '<script type="text/javascript"> alert("Order is Completed..."); document.location.href="userorder.php"; </script>';
	}
?>	
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Nirma Canteen | Home</title>

    <!-- Favicon -->
    <?php include("headerscript.php"); ?>
    <script type="text/javascript">
	$(document).ready(function(e) {
        $("#quantity").blur(function(e) {
            var qty = $(this).val();
			$("#tamount").val(parseFloat(qty)*parseFloat($("#amount").val()));
        });
    });

</script>
<script type="text/javascript">
	function confirmme()
		{
			if(confirm("Confirm Your Order"))
			{
				return true;
			}
			return false;
			
		}
	</script>
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
<?php include("staffheader.php"); ?>
    <section id="mu-reservation" style="padding-top:150px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-reservation-area">
            <div class="mu-title">
              <span class="mu-subtitle">Customer Order</span>
              <h2>Detail</h2>
              <i class="fa fa-spoon"></i>              
              <span class="mu-title-bar"></span>
            </div>
            
            <div class="mu-reservation-content" style="padding:0px;">
               							<?php 
										$str1234 = "SELECT T.*,F.email FROM tbl_order as T INNER JOIN register as F ON F.sid=T.userId WHERE T.IsPay='1' AND T.IsConfirm<>'1'";
										$FCards = mysql_query($str1234) or die("Error: Select Query problem");
										$num = mysql_num_rows($FCards);
										if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													 <th>Order No</th>
                                                     <th>User EmailId</th>
													<th>Quantity</th>
                                                    <th>Total Amount</th>
                                                    
                                                    <th>Order Date</th>
                                                    
                                                    <th>Order Status</th>
												</tr>
												</thead>
												<tbody>
												<?php
												$GTotal = 0;
												$i = 1;
												 while($Rows = mysql_fetch_array($FCards))
												{
													$GTotal += $Rows["TotalAmount"];
												?>
												<tr>
													<td class="td-actions"><a href="?process=<?php echo $Rows["OrderId"]; ?>" class="btn btn-primary btn-small">Processing</a>
                                                    <a href="?complete=<?php echo $Rows["OrderId"]; ?>" class="btn btn-success btn-small">Complete</a>
                                                    </td>
                                                    <td><?php echo $Rows["OrderId"]; ?></td>
													<td><a href="#popup<?php echo $i; ?>"><?php echo $Rows["email"]; ?></a>
<div id="popup<?php echo $i++; ?>" class="overlay">
	<div class="popup">
		<h2>Order Items Details</h2>
		<a class="close" href="#">&times;</a>
		<div class="content">
			<?php 
										$str12 = "SELECT T.*,F.FoodName,F.Amount FROM tbl_orderitem as T INNER JOIN tbl_foodmenu as F ON F.FoodId=T.FoodId WHERE T.Orderid='".$Rows["OrderId"]."'";
										$FCards12 = mysql_query($str12) or die("Error: Select Query problem");
										$num12 = mysql_num_rows($FCards12);
										if($num12 > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr> <th>Items Name</th>
													<th>Quantity</th>
                                                    <th>Price</th>
                                                    <th>Total Amount</th>
												</tr>
												</thead>
												<tbody>
												<?php
												 while($Rows12 = mysql_fetch_array($FCards12))
												{
												?>
												<tr>
													<td><?php echo $Rows12["FoodName"]; ?></td>
													<td><?php echo $Rows12["Quantity"]; ?></td>
													
                                                    <td><?php echo $Rows12["Amount"]; ?></td>
													<td><?php echo $Rows12["TotalAmount"]; ?></td>
												</tr>
												<?php } ?>
                                                
												</tbody>
											</table>    
                                            <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Cart</div>
                                        <?php } ?>
		</div>
	</div>
</div>
													</td>
													<td><?php echo $Rows["Quantity"]; ?></td>
													
													<td><?php echo $Rows["TotalAmount"]; ?></td>
                                                    
                                                    <td><?php echo $Rows["orderdate"]; ?></td>
                                                    
                                                    <td><?php echo $Rows["IsConfirm"]==0?"<b style='color:red'>Pending</b>":"<b style='color:#5cb85c'>Processing</a>"; ?></td>
												</tr>
												<?php } ?>
                  
												</tbody>
											</table>  
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Order</div>
                                        <?php } ?>
                  
            <!--<div class="mu-restaurant-menu-content">
              <ul class="nav nav-tabs mu-restaurant-menu">
                <li class="active"><a href="#breakfast" data-toggle="tab">Breakfast</a></li>
                <li><a href="#meals" data-toggle="tab">Meals</a></li>
                <li><a href="#snacks" data-toggle="tab">Snacks</a></li>
                <li><a href="#desserts" data-toggle="tab">Desserts</a></li>
                <li><a href="#drinks" data-toggle="tab">Drinks</a></li>
              </ul>
            </div>-->
          </div>
         
        </div>
      </div>
    </div>
  </div>
</div>
</section>
    <?php include("footer.php"); ?>

  </body>
  
</html>