<footer id="mu-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <div class="mu-footer-area">
           
          <div class="mu-footer-copyright">
            <p>Developed by <a rel="nofollow" href="#">Nirma University</a></p>
          </div>         
        </div>
      </div>
      </div>
    </div>
  </footer>
  