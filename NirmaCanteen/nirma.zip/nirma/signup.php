<?php
    mysql_connect("localhost", "root" ,"")or die("error in connection");
    mysql_select_db("canteen")or die("Errron in select");

    if(isset($_POST["submit"]))
      {
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $add = $_POST["add"];
        $mno = $_POST["mno"];
        $gender = $_POST["sex"];
        $email = $_POST["email"];
        $pwd = $_POST["pass"];
         $ins = "INSERT INTO register(fname,lname,address,mno,gender,email,pwd) VALUES('$fname','$lname','$add','$mno','$gender','$email','$pwd')";
      
      mysql_query($ins); 
      header("location:login.php?msg=Record selected sucessfully");
      }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>SpicyX | Home</title>

    <!-- Favicon -->
    <?php include("headerscript.php"); ?>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <script>
  function validateForm()
  {

  var fname = document.forms["myForm"]["fname"]; //name
   if(fname.value == "")
  {
   alert("Please, Enter First Name");
   fname.focus();
   return false;
  }

  var lname = document.forms["myForm"]["lname"]; //name
   if(lname.value == "")
  {
   alert("Please, Enter Last Name");
   lname.focus();
   return false;
  }

  var add = document.forms["myForm"]["add"];
   if(add.value == "")
  {
   alert("Please, Enter Address");
   add.focus();
   return false;
  }

  

  var mno = document.forms["myForm"]["mno"];
   if(mno.value == "")
  {
   alert("Please enter your MOBILE No");
   mno.focus();
   return false;

  }

  var lname = document.forms["myForm"]["sex"]; //name
   if(lname.value == "")
  {
   alert("Please, Select Gender");
   lname.focus();
   return false;
  }

    var lname = document.forms["myForm"]["email"]; //name
   if(lname.value == "")
  {
   alert("Please, Enter Email Id");
   lname.focus();
   return false;
  }
     var x = document.forms["myForm"]["email"].value;
    var atpos = x.indexOf("@nirmauni");
    var dotpos = x.lastIndexOf(".ac.in");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
    {
      alert("Not a valid email address");
      return false;
    }
     var pas = document.forms["myForm"]["pass"];
   if(pas.value == "")
  {
   alert("Please, Enter Password");
   pas.focus();
   return false;

  }
   var cpas = document.forms["myForm"]["cpass"];
   if(cpas.value == "")
  {
   alert("Please, Enter Conform Password");
   cpas.focus();
   return false;

  }
  var pas = document.forms["myForm"]["pass"];
    var cpas = document.forms["myForm"]["cpass"];
    if(pas.value != cpas.value)
    {
    alert("Please, Enter Same Password");
   cpas.focus();
   return false;
    }
    return true;

  }
  </script>
  <body>  
<!-- Pre Loader -->
  <!--<div id="aa-preloader-area">
    <div class="mu-preloader">
      <img src="assets/img/preloader.gif" alt=" loader img">
    </div>
  </div> -->
  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>
      <span>Top</span>
    </a>
  <!-- END SCROLL TOP BUTTON -->

  <!-- Start header section -->
  <!-- End header section -->
 
<?php include("header.php"); ?>

  <!-- Start slider  -->
 <?php //include("slider.php"); ?> 
   <!-- Start Contact section -->
  <section id="mu-contact">
    <div class="container" style="padding-top: 20px;">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-contact-area">
            <div class="mu-title">
              <span class="mu-subtitle">Get In Touch</span>
              <h2>Sign Up</h2>
              <i class="fa fa-spoon"></i>              
              <span class="mu-title-bar"></span>
            </div>
            <div class="mu-contact-content">
              <div class="row">
                <div class="col-md-6">
                  <div class="mu-contact-left">
                    <form class="mu-contact-form" method="POST" name="myForm" onsubmit="return validateForm();">
                      <div class="form-group">
                        <label for="name">First Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" placeholder="Name">
                      </div>
                      <div class="form-group">
                        <label for="lname">Last Name</label>
                        <input type="text" class="form-control" id="lname" name="lname"placeholder="Last Name">
                      </div>
                      <div class="form-group">
                        <label for="address">Address</label>
                        <input type="textarea" class="form-control" id="add" name="add"placeholder="Address">
                      </div>
                      
                      <div class="form-group">
                        <label for="mobileno">Mobile No</label>
                        <input type="number" name="mno" class="form-control" id="mno" placeholder="Mobile No">
                      </div>

                      <div class="form-group">
                        <select id="sex" name="sex" placeholder="I am.." class="form-control" >
                        <option value="">I am...</option>
                        <option value="male">Male</option>
                         <option value="female">female</option>
                         </select> 
                      </div>

                      <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" name="email" class="form-control" id="email" placeholder="@nirmauni.ac.in" >
                      </div>   

                       <div class="form-group">
                        <label for="pass">Password</label>
                        <input type="password" name="pass" id="pass"class="form-control" id="pass" placeholder="Password">
                      </div> 

                      <div class="form-group">
                        <label for="cpass">Confirm Password</label>
                        <input type="password" name="cpass" id="cpass"class="form-control" id="cpass" placeholder="Conform Password">
                      </div> 
                                           
                      <!-- <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" class="form-control" id="subject" placeholder="Subject">
                      </div> -->
                     <!-- <div class="form-group">
                        <label for="message">Message</label>                        
                        <textarea class="form-control" id="message" cols="30" rows="10" placeholder="Type Your Message"></textarea>
                      </div>  -->                     
                      <button type="submit" name="submit" class="mu-readmore-btn" onClick="return validation();">Signup</button>
                    </form>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mu-contact-right">
                    <div class="mu-contact-widget">
                      <h3>Nirma Canteen Address</h3>
                      <p>Address: Sarkhej-Gandhinagar Highway, 
                          POST : Chandlodia, Via : Gota, 
                          Ahmedabad - 382 481.
                          Gujarat, India.</p>
                      <address>
                        Contact




                        <p><i class="fa fa-phone"></i> 
                          Phone:+91 - 079 - 30642000/100/200/300/400 
                          Fax: +91 - 2717 - 241917
                        </p>
                        <p><i class="fa fa-envelope-o"></i>dy_registrar.it@nirmauni.ac.in</p>
                        
                      </address>
                    </div>
                    <div class="mu-contact-widget">
                      <h3>Open Hours</h3>                      
                      <address>
                        <p><span>Monday - Friday</span> 9:00 am to 6:00 pm</p>
                        <p><span>Saturday</span> 9:00 am to 2:00 pm</p>
                        <p><span>Sunday</span> 10:00 am to 12:00 pm</p>
                      </address>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Contact section -->

 
 <?php include("footer.php"); ?>
</body>
</html>