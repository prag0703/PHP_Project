<?php 
	session_start();
	if(!isset($_SESSION["SId"]))
	{
		header("location:login.php?requestUrl=corder.php?".$_SERVER['QUERY_STRING']);
	}
	
	mysql_connect("localhost","root","") or die("Error: Connection problem");
	mysql_select_db("canteen") or die("Error: No Databse found :-: canteen");

	if(isset($_POST["submit"]))
	{
		$Foodname = $_POST["foodId"];
		$quantity = $_POST["quantity"];
		$tamount = $_POST["tamount"];
		$UserId = $_SESSION["SId"];
		
		$str = "INSERT INTO tbl_orderitem(userId,FoodId,Quantity,TotalAmount) VALUES('$UserId','$Foodname','$quantity','$tamount')";
		
		mysql_query($str) or die("Error: Insert query problem");
		
		
		
		echo '<script type="text/javascript"> alert("Order Added in Cart successfully"); document.location.href="index.php#mu-restaurant-menu"; </script>';
	}
?>	
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>SpicyX | Home</title>

    <!-- Favicon -->
    <?php include("headerscript.php"); ?>
    <script type="text/javascript">
	$(document).ready(function(e) {
        $("#quantity").blur(function(e) {
            var qty = $(this).val();
			$("#tamount").val(parseFloat(qty)*parseFloat($("#amount").val()));
        });
    });

</script>
<script type="text/javascript">
	function confirmme()
		{
			if(confirm("Confirm Your Order"))
			{
				return true;
			}
			return false;
			
		}
	</script>
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
<?php include("header.php"); ?>
    <section id="mu-reservation" style="padding-top:150px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-reservation-area">
            <div class="mu-title">
              <span class="mu-subtitle">Customer Order</span>
              <h2>Detail</h2>
              <i class="fa fa-spoon"></i>              
              <span class="mu-title-bar"></span>
            </div>
            
            <div class="mu-reservation-content">
               
             		<div class="col-md-8">
                    <form class="mu-contact-form" method="post" action="">
                      <div class="form-group">
                        <label for="name">Food Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo base64_decode($_GET["foodname"]); ?>" readonly>
                        <input type="hidden" class="form-control" id="foodId" name="foodId" value="<?php echo base64_decode($_GET["foodId"]); ?>" readonly>
                      </div>
                      <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="text" class="form-control" id="amount" name="amount" value="<?php echo base64_decode($_GET["itemtype"]); ?>" readonly>
                      </div>                      
                      <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Quantity">
                      </div>
                      
                      <div class="form-group">
                        <label for="tamount">Total Amount</label>
                        <input type="number" class="form-control" id="tamount" name="tamount" readonly>
                      </div>
                      <button type="submit" name="submit" id="submit" class="mu-readmore-btn" style="border:none;" onClick="return confirmme()">Add Now</button>
                    </form>
                  </div>
                  
            <!--<div class="mu-restaurant-menu-content">
              <ul class="nav nav-tabs mu-restaurant-menu">
                <li class="active"><a href="#breakfast" data-toggle="tab">Breakfast</a></li>
                <li><a href="#meals" data-toggle="tab">Meals</a></li>
                <li><a href="#snacks" data-toggle="tab">Snacks</a></li>
                <li><a href="#desserts" data-toggle="tab">Desserts</a></li>
                <li><a href="#drinks" data-toggle="tab">Drinks</a></li>
              </ul>
            </div>-->
          </div>
         
        </div>
      </div>
    </div>
  </div>
</div>
</section>
    <?php include("footer.php"); ?>

  </body>
  
</html>