<?php
	include("connection.php");
	session_start();

 	$usrname = $_REQUEST['usrname'];
 	$password = md5($_REQUEST['password']);

	$query = "select * from tbl_login where usr_name='".$uname."' and password='".$password."' ";
	//echo $query;
	$sql = mysql_query($query) or die("Error In Query");
	$row = mysql_fetch_array($sql);
	
	$count=mysql_num_rows($sql);
	if($count==1)
	{
		if($row['password']==$password)
		{
			$_SESSION['usr_name'] = $row['usrname'];
			$_SESSION['admin_id'] = $row['a_id'];
			header("Location:home.php");
		}
		else
			header("location:index.php?error=status");	
	}
	else
	{
		header("location:index.php?error=count");
	}
?>