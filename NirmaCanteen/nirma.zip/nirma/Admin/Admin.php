


<?php
	require("include/sessionchecker.php");
?>

<?php

require("dbConfig/dbConfig.php");

if(isset($_POST["Submit"]))
{
	$name = $_POST["name"];
	$contact = $_POST["mob"];
	$email = $_POST["email"];
	$login = $_POST["loginid"];
	$password = $_POST["password"];
	
	$str = "INSERT INTO tbl_admin(name,contact,email_id,login_id,password) VALUES('$name','$contact','$email','$login','$password')";
	mysql_query($str) or die("Error: Insert query problem");
	header("location:Admin.php?msg=Record Inserted sucessfully");
}

if(isset($_POST["editbtn"]))
{
	$name = $_POST["name"];
	$contact = $_POST["mob"];
	$email = $_POST["email"];
	$login = $_POST["loginid"];
	$password = $_POST["password"];
	$Id = $_POST["edId"];
	
	$str = "UPDATE tbl_admin SET name='$name',contact='$contact',email_id='$email',login_id='$login',password='$password' WHERE a_id='$Id'";
	mysql_query($str) or die("Error: Update query problem");
	header("location:Admin.php?msg=Record Updated sucessfully");
}


if(isset($_GET["delId"]))
{
	$Id = base64_decode($_GET["delId"]);
	$str = "DELETE FROM tbl_admin WHERE a_id='$Id'";
	mysql_query($str) or die("Error: Insert query problem");	
	header("location:Admin.php?msg=Record Deleted sucessfully");
}

$selstr = "SELECT * FROM tbl_admin";
$Data = mysql_query($selstr) or die("Error: Select Query problem");
$num = mysql_num_rows($Data);

	
if(isset($_GET["edId"]))
{
	$Id = base64_decode($_GET["edId"]);
	$str = "SELECT * FROM tbl_admin WHERE a_id='$Id'";
	$Edata=mysql_query($str) or die("Error:  query problem");
	$ERows = mysql_fetch_assoc($Edata);
}
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<script>
function validationform()
{
function namevalid()
{
	var name = /^[a-zA-Z\s-, ]+$/;;
    var val = document.getElementById('name');
    if (name.test(val.value) == false) 
		{
			document.getElementById('divname').innerHTML="Please Enter valid name.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divname').innerHTML="";
			return true;
        }  
} 
 
function mobilenum()
{
	var mob = /^[1-9]{1}[0-9]{9}$/;
    var val = document.getElementById('admincontact');
    if (mob.test(val.value) == false) 
		{
			document.getElementById('divnum').innerHTML="Please enter valid mobile number.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divnum').innerHTML="";
			return true;
        }  
} 

function validmail(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail').innerHTML="Please enter valid email";  
		return false;
  	}
} 

function validmail1(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail1').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail1').innerHTML="Please enter valid id";  
		return false;
  	}
} 

}
</script>
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list-alt"></i>
              				<h3> Admin Details	</h3>
            			</div>
            <!-- /widget-header -->
        				<div class="widget-content">
             				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                      					<div class="stats" align="center">
                    	
                        				<?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        <?php } ?>
                        
                        		<form action="" method="post" onSubmit="return validationform()">
                          
                           
                             <table cellpadding="10px">
                             	
                                <tr>
                                    <td>Admin Name</td>
                                    <td><input type="text" name="name" id="name" placeholder="Enter Admin Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["name"]; ?>"<?php } ?> onBlur="namevalid();" /></td>
                                   <td><span id="divname" style="color:#930 !important"> *</span></td>
                                    
                                </tr>
                           	 
                           		<tr>
                                
                           		<td>Contact</td>
                           		<td><input type="number" name="admincontact" id="admincontact" placeholder="Enter Admin Contact" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["contact"]; ?>" <?php } ?> onblur="mobilenum();"/></td>
                                <td><span id="divnum" style="color:#930 !important"> *</span></td>
                          
                           </tr>
                           
                           	<tr>
                            
                           	<td>Email ID </td>
                           	<td><input type="email" name="email"  placeholder="Enter Admin E-mail" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["email_id"]; ?>" <?php } ?>  onBlur="validmail(this.value);"/></td>
                            <td><span id="divmail" style="color:#930 !important"> *</span></td>
                            </tr>
                            
                            <tr>
                           	<td>Login ID</td>
                           	<td><input type="email" name="loginid" placeholder="Enter Admin Login" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["login_id"]; ?>" <?php } ?> onBlur="validmail1(this.value);" /></td>
                             <td><span id="divmail1" style="color:#930 !important"> *</span></td>
                           	
                            </tr>
                           
                          
                           
                           <tr>
  							<td>Password</td>
                            <td><input type="password" name="password"  placeholder="Enter Admin Password" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["password"]; ?>" <?php } ?>/></td>
   							</tr>
                            <tr>
                                            
                  <tr>
            		<td></td>
            		<td>
                    <?php if(isset($ERows)){ ?>
                    <input type="submit" name="editbtn" value="Update" class="btn-primary btn-large">
                    <input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    <?php } else { ?>
                    <input type="submit" name="Submit" class="btn-primary btn-large" />
                    <?php } ?>
                    </td>
            	  </tr>
                                         </table>
                                        </form>
                                        <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Admin</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Admin Name</th>
                                                <tH>Contact</tH>
                                                <th>Email Id</th>
                                                <th>Login Id</th>
                                                <th>Password</th>
                                                <th>Register Date</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["a_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["a_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["a_id"]; ?></td>
                                                <td><?php echo $Rows["name"]; ?></td>
                                                <td><?php echo $Rows["contact"]; ?></td>
                                                <td><?php echo $Rows["email_id"]; ?></td>
                                                <td><?php echo $Rows["login_id"]; ?></td>
                                                <td><a href="#" title="<?php echo $Rows["password"]; ?>">********</a></td>
                                                <td><?php echo $Rows["register_date"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>
 </body>
</html>
          