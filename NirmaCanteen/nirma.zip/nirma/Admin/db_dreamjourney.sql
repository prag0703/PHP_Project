-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 06, 2016 at 12:19 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_dreamjourney`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `a_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `contact` int(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `login_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`a_id`, `name`, `contact`, `email_id`, `login_id`, `password`, `register_date`) VALUES
(5, 'Kaushik', 2147483647, 'abc@gmail.com', 'abc@gmail.com', 'admin', '2016-02-27 05:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `customer_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `contact` int(20) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `Login_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `name`, `address`, `state`, `city`, `zipcode`, `contact`, `email_id`, `Login_id`, `password`, `register_date`) VALUES
(6, 'Kaushik makholiya', 'sidhasar', 'Gujarat', 'Ahmedabad', 363430, 1234567890, 'kaushik.makholiya@gmail.com', 'kaushik.makholiya@gmail.com', '1234567890', '2016-02-26 05:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE IF NOT EXISTS `tbl_feedback` (
  `f_id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_id` int(50) NOT NULL,
  `feedback` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_inquiry`
--

CREATE TABLE IF NOT EXISTS `tbl_inquiry` (
  `inquiry_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` int(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `massage` varchar(50) NOT NULL,
  `inquiry_date` date NOT NULL,
  `is_read` tinyint(1) NOT NULL,
  PRIMARY KEY (`inquiry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `u_id` int(10) NOT NULL AUTO_INCREMENT,
  `usr_name` varchar(50) NOT NULL,
  `usr_pass` varchar(50) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`u_id`, `usr_name`, `usr_pass`) VALUES
(1, 'Kaushik', 'kaushik'),
(2, 'kaushikpatel', 'patel');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `pay_id` int(50) NOT NULL AUTO_INCREMENT,
  `pay_mode` varchar(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `t_amount` double NOT NULL,
  `paid_date` date NOT NULL,
  `pay_for` varchar(50) NOT NULL,
  `service_id` varchar(50) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tbooking`
--

CREATE TABLE IF NOT EXISTS `tbl_tbooking` (
  `tb_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(50) NOT NULL,
  `tp_id` varchar(50) NOT NULL,
  `Description` text NOT NULL,
  `no_of_person` int(50) NOT NULL,
  `total_amount` int(50) NOT NULL,
  `booking_date` date NOT NULL,
  `orderCode` varchar(6) NOT NULL,
  PRIMARY KEY (`tb_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_tbooking`
--

INSERT INTO `tbl_tbooking` (`tb_id`, `customer_id`, `tp_id`, `Description`, `no_of_person`, `total_amount`, `booking_date`, `orderCode`) VALUES
(1, 'kaushik.makholiya@gmail.com', 'Kaushik', 'ASDASDASDASD', 2, 50, '0000-00-00', 'AUmKik');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tpackage`
--

CREATE TABLE IF NOT EXISTS `tbl_tpackage` (
  `tp_id` int(50) NOT NULL AUTO_INCREMENT,
  `p_name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `p_amount` varchar(50) NOT NULL,
  `discription` varchar(50) NOT NULL,
  `is_active` varchar(20) NOT NULL,
  `payment_term` varchar(50) NOT NULL,
  PRIMARY KEY (`tp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_tpackage`
--

INSERT INTO `tbl_tpackage` (`tp_id`, `p_name`, `start_date`, `end_date`, `state`, `city`, `p_amount`, `discription`, `is_active`, `payment_term`) VALUES
(7, 'Kaushik', '2016-02-02', '2016-02-03', 'Gujarat', 'Ahmedabad', '25', '   Patel  kaushik                                ', 'yes', '27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tplanner`
--

CREATE TABLE IF NOT EXISTS `tbl_tplanner` (
  `tp_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` varchar(50) NOT NULL,
  PRIMARY KEY (`tp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_tplanner`
--

INSERT INTO `tbl_tplanner` (`tp_id`, `name`, `address`, `state`, `city`, `zipcode`, `contact`, `email_id`, `password`, `register_date`, `is_active`) VALUES
(4, 'Kaushik makholiya', 'AT-sidhasar', 'Gujarat', 'City', 363430, '1234567890', 'kaushik.makholiya@gmail.com', '1234567890', '2016-02-26 14:12:26', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trrequest`
--

CREATE TABLE IF NOT EXISTS `tbl_trrequest` (
  `tr_id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(50) NOT NULL,
  `tour_id` varchar(50) NOT NULL,
  `no_of_days` varchar(50) NOT NULL,
  `no_of_seat` varchar(50) NOT NULL,
  `payment_term` varchar(50) NOT NULL,
  `is_confirm` varchar(50) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `confirm_date` date NOT NULL,
  PRIMARY KEY (`tr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_trrequest`
--

INSERT INTO `tbl_trrequest` (`tr_id`, `customer_id`, `tour_id`, `no_of_days`, `no_of_seat`, `payment_term`, `is_confirm`, `request_date`, `confirm_date`) VALUES
(1, 'kaushik.makholiya@gmail.com', '1234', '3', '5', '25', 'no', '2016-02-26 15:22:02', '2016-02-03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vagency`
--

CREATE TABLE IF NOT EXISTS `tbl_vagency` (
  `ag_id` int(50) NOT NULL AUTO_INCREMENT,
  `ag_name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approve` varchar(50) NOT NULL,
  PRIMARY KEY (`ag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_vagency`
--

INSERT INTO `tbl_vagency` (`ag_id`, `ag_name`, `address`, `city`, `state`, `zipcode`, `email_id`, `password`, `register_date`, `is_approve`) VALUES
(3, 'Kaushik LTD', '                    AT-sidhasar                   ', 'Ahmedabad', 'Gujarat', 363432, 'kaushik.makholiya@gmail.com', '1234567890', '2016-02-26 17:36:36', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicles`
--

CREATE TABLE IF NOT EXISTS `tbl_vehicles` (
  `v_id` int(50) NOT NULL AUTO_INCREMENT,
  `agency_id` varchar(50) NOT NULL,
  `v_name` varchar(50) NOT NULL,
  `v_type` varchar(50) NOT NULL,
  `v_no` varchar(30) NOT NULL,
  `price_per_km` int(11) NOT NULL,
  `v_permission` varchar(20) NOT NULL,
  `vimg` varchar(100) NOT NULL,
  `no_of_seat` int(20) NOT NULL,
  `is_available` varchar(20) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_vehicles`
--

INSERT INTO `tbl_vehicles` (`v_id`, `agency_id`, `v_name`, `v_type`, `v_no`, `price_per_km`, `v_permission`, `vimg`, `no_of_seat`, `is_available`, `upload_date`) VALUES
(15, '123', '123', 'twowheeler', '123456', 123, 'no', '26021612023155', 12, 'no', '2016-02-26 12:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vrequest`
--

CREATE TABLE IF NOT EXISTS `tbl_vrequest` (
  `vr_id` int(50) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(50) NOT NULL,
  `v_id` varchar(50) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `travel_date` date NOT NULL,
  `return_date` date NOT NULL,
  `estimate_km` float NOT NULL,
  `comment` varchar(50) NOT NULL,
  `is_approve` varchar(50) NOT NULL,
  PRIMARY KEY (`vr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_vrequest`
--

INSERT INTO `tbl_vrequest` (`vr_id`, `customer_id`, `v_id`, `request_date`, `travel_date`, `return_date`, `estimate_km`, `comment`, `is_approve`) VALUES
(9, 'ka@gmail.com', '1324567', '2016-02-26 15:57:28', '2016-02-01', '2016-02-02', 87, 'anything', 'no');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
