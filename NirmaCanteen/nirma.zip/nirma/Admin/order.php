
<?php
	require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$Foodname = $_POST["fname"];
		$quantity = $_POST["quantity"];
		$tamount = $_POST["tamount"];
		
		
		$str = "INSERT INTO tbl_order(FoodId,Quantity,TotalAmount) VALUES('$Foodname','$quantity','$tamount')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:order.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$Id = $_POST["edId"];
		$Foodname = $_POST["fname"];
		$quantity = $_POST["quantity"];
		$tamount = $_POST["tamount"];
		
		$str = "UPDATE tbl_order SET FoodId='$Foodname',Quantity='$quantity',TotalAmount='$tamount' WHERE OrderId='$Id'";
		
		mysql_query($str) or die("Error: Updated query problem");
		header("location:order.php?msg=Record Updated sucessfully");
	}
	
		if(isset($_GET["delId"]))
		{
			$Id = (base64_decode($_GET["delId"]));
			$str = "DELETE FROM tbl_order WHERE OrderId='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:order.php?msg=Record Deleted sucessfully");
		}

		$selstr = "SELECT T.*,F.FoodName,R.fname,R.lname FROM tbl_order as T INNER JOIN tbl_foodmenu as F ON F.FoodId=T.FoodId INNER JOIN register as R ON R.sid=T.UserId";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

		$str1 = "SELECT * FROM tbl_foodmenu ";
		$FData = mysql_query($str1) or die("Error: Select Query problem");

	if(isset($_GET["edId"]))
		{
			$Id = $_GET["edId"];
			$str = "SELECT * FROM tbl_order WHERE OrderId='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
		}
		
?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="utf-8">
	<title>Nirma Canteen Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
			rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
    <script type="text/javascript">
	function confirmme()
		{
			if(confirm("Are you sure want to delete?"))
			{
				return true;
			}
			return false;
			
		}
	</script>
	</head>
	<body>
	<?php include("Include/header.php"); ?>
	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget widget-nopad">
							<!--<div class="widget-header"> <i class="icon-list"></i>
								<h3> Order Details	</h3>
							</div>-->
				<!-- /widget-header -->
			   <?php /*?><div class="widget-content">
				  <div class="widget big-stats-container">
					<div class="widget-content">
					  <div id="big_stats" class="cf">
						<div class="stats" align="center">
						
						<?php if(isset($_GET["msg"])){?>
												<div class="alert alert-success">
												<?php echo $_GET["msg"]; ?>
												</div> 
											<?php } ?>
							
											
						 <form action="" method="post">
						 
                         <table cellpadding="10px">
						  <tr>
							<td>Food Name</td>
							<td><select name="fname" id="fname" value="">
                        		<?php if($FData !=0 ) { while($ERows=mysql_fetch_array($FData)) {?>
								
								<option value="<?php echo $ERows["FoodId"]; ?>" ><?php echo $ERows["FoodName"]; ?></option>
								<?php } } ?>
								
							 </select>
                             </td>
						  </tr>
						<tr>	
						   <td>Amount</td>
						  <td><input type="text" name="amount" id="amount" value="" readonly onBlur="pincodes();"/></td>
                           <td><span id="amount" style="color:#930 !important"> *</span></td>
						</tr>				 
						 <tr>
						   <td>Quantity</td>
						  <td><input type="number" name="quantity" id="quantity" placeholder="Enter Quantity" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["tamount"]; ?>"<?php } ?> onBlur="pincodes();"/></td>
                           <td><span id="c_address" style="color:#930 !important"> *</span></td>
						</tr>
					   <tr>                         
					   <td>Total Amount</td>
					   <td><input type="number" name="tamount" id="tamount" readonly <?php if(isset($ERows)) { ?>value="<?php echo $ERows["tamount"]; ?>"<?php } ?> /></td>
                       
					   </tr>
					   
					   
					  <tr>
					<td></td>
					<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
					</td>
				</tr>
					   </table>
											</form><?php */?>
											
											<div class="widget widget-table action-table">
											<div class="widget-header"> <i class="icon-th-list"></i>
											  <h3>Order Details</h3>
											</div>
											<!-- /widget-header -->
											<div class="widget-content">
										            							<?php 
										$str1234 = "SELECT T.*,F.email FROM tbl_order as T INNER JOIN register as F ON F.sid=T.userId";
										$FCards = mysql_query($str1234) or die("Error: Select Query problem");
										$num = mysql_num_rows($FCards);
										if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													 <th>Order No</th>
													 <th>View Order</th>
													 <th>User Name</th>
													<th>Quantity</th>
                                                    <th>Total Amount</th>
                                                    
                                                    <th>Order Date</th>
                                                    
                                                    <th>Order Status</th>
												</tr>
												</thead>
												<tbody>
												<?php
												$GTotal = 0;
												$i=1;
												 while($Rows = mysql_fetch_array($FCards))
												{
													$GTotal += $Rows["TotalAmount"];
												?>
												<tr>
												
                                                    <td><?php echo $Rows["OrderId"]; ?>
													</td>
													<td><a href="#popup<?php echo $i; ?>">View Order</a>
                 <div id="popup<?php echo $i++; ?>" class="overlay">
	<div class="popup">
		<h2>Order Items Details</h2>
		<a class="close" href="#">&times;</a>
		<div class="content">
			<?php 
										$str12 = "SELECT T.*,F.FoodName,F.Amount FROM tbl_orderitem as T INNER JOIN tbl_foodmenu as F ON F.FoodId=T.FoodId WHERE T.Orderid='".$Rows["OrderId"]."'";
										$FCards12 = mysql_query($str12) or die("Error: Select Query problem");
										$num12 = mysql_num_rows($FCards12);
										if($num12 > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr> <th>Items Name</th>
													<th>Quantity</th>
                                                    <th>Price</th>
                                                    <th>Total Amount</th>
												</tr>
												</thead>
												<tbody>
												<?php
												 while($Rows12 = mysql_fetch_array($FCards12))
												{
												?>
												<tr>
													<td><?php echo $Rows12["FoodName"]; ?></td>
													<td><?php echo $Rows12["Quantity"]; ?></td>
													
                                                    <td><?php echo $Rows12["Amount"]; ?></td>
													<td><?php echo $Rows12["TotalAmount"]; ?></td>
												</tr>
												<?php } ?>
                                                
												</tbody>
											</table>    
                                            <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Cart</div>
                                        <?php } ?>
		</div>
	</div>
</div>
													</td>
													<td><?php echo $Rows["email"]; ?></td>
													<td><?php echo $Rows["Quantity"]; ?></td>
													
													<td><?php echo $Rows["TotalAmount"]; ?></td>
                                                    
                                                    <td><?php echo $Rows["orderdate"]; ?></td>
                                                    
                                                    <td><?php echo $Rows["IsConfirm"]==1?"<b style='color:#c96'>Completed</b>":($Rows["IsConfirm"]==0?"<b style='color:red'>Pending</b>":"<b style='color:#5cb85c'>Processing</a>"); ?></td>
												</tr>
												<?php } ?>
                  
												</tbody>
											</table>  
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Order</div>
                                        <?php } ?>
      
											
											</div>
											 </div>
										</div>
									</div>
					<!-- /widget-content --> 
					
								</div>
							</div>
						 </div>
					</div>
				</div>
			  </div>
		  </div>
	   </div>
	   <?php include("Include/footer.php"); ?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>
<script type="text/javascript">

$(document).ready(function(e){
	$("#fname").change(function(e) {
		 var respo = $.ajax({url:"getfoodcost.php?FoodId="+$(this).val(),async:false,cach:false}).responseText;
         $("#amount").val(respo);
         if($("#quantity").val()!="")
         {
        	 var tamount = parseFloat($("#quantity").val()) * parseFloat($("#amount").val()); 
        	$("#tamount").val(tamount);
    	}
	});

	$("#quantity").blur(function(){
        var tamount = parseFloat($(this).val()) * parseFloat($("#amount").val()); 
        $("#tamount").val(tamount);
	});
});

</script>

	 </body>
	</html>
			  