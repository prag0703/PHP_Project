
<?php
	require("include/sessionchecker.php");
?>

<?php

require("dbConfig/dbConfig.php");

if(isset($_POST["Submit"]))
{
	$agencyid = $_POST["agencyid"];
	$vname = $_POST["vehiclename"];
	$vtype = $_POST["vehicletype"];
	$vno = $_POST["vehicleno"];
	$priceperkm = $_POST["priceperkm"];
	$vpermission = $_POST["vehiclepermission"];
	//$vimg = $_FILE["vimg"];
	$noofseat = $_POST["noofseat"];
	$isavailable = $_POST["isavailable"];
	
		$vimg = $_FILES["vimg"];
		$Ext = strrchr($vimg["name"],".");
		$NewImg = date("dmyhmsi").$Ext;
		if($vimg["name"]!="")
		{
			move_uploaded_file($vimg["tmp_name"],"upload/".$NewImg);
		}
	
	$str = "INSERT INTO tbl_vehicles(agency_id,v_name,v_type,v_no,price_per_km,v_permission,vimg,is_available) VALUES('$agencyid','$vname','$vtype','$vno','$priceperkm','$vpermission','$NewImg','$isavailable')";
	mysql_query($str) or die("Error: Insert query problem");
	header("location:vehicle.php?msg=Record Inserted sucessfully");
}

if(isset($_POST["editbtn"]))
{
	$agencyid = $_POST["agencyid"];
	$vname = $_POST["vehiclename"];
	$vtype = $_POST["vehicletype"];
	$vno = $_POST["vehicleno"];
	$priceperkm = $_POST["priceperkm"];
	$vpermission = $_POST["vehiclepermission"];
	//$vimg = $_FILE["vimg"];
	$noofseat = $_POST["noofseat"];
	$isavailable = $_POST["isavailable"];
	$vimg = $_FILES["vimg"];
		$Ext = strrchr($vimg["name"],".");
		$NewImg = date("dmyhmsi").$Ext;
		if($vimg["name"]!="")
		{
			move_uploaded_file($vimg["tmp_name"],"upload/".$NewImg);
		}
	
	$str ="UPDATE tbl_vehicles SET agency_id='$agencyid',v_name='$vname',v_type='$vtype',v_no='$vno',price_per_km='$priceperkm',v_permission='$vpermission',vimg='$NewImg',is_available='$isavailable'";
	mysql_query($str) or die("Error: Insert query problem");
	header("location:vehicle.php?msg=Record Inserted sucessfully");
}


if(isset($_GET["delId"]))
{
	$Id = base64_decode($_GET["delId"]);
	$str = "DELETE FROM tbl_vehicles WHERE v_id='$Id'";
	mysql_query($str) or die("Error: Insert query problem");	
	header("location:vehicle.php?msg=Record Deleted sucessfully");
}


$selstr = "SELECT * FROM tbl_vehicles";
$Data = mysql_query($selstr) or die("Error: Select Query problem");
$num = mysql_num_rows($Data);

if(isset($_GET["edId"]))
{
	$Id = base64_decode($_GET["edId"]);
	$str = "SELECT * FROM tbl_vehicles WHERE v_id='$Id'";
	$Edata = mysql_query($str) or die("Error: Insert query problem");	
	$ERows = mysql_fetch_assoc($Edata);
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	<script>
		
		function validmail1(val)   
		{  
			if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
			{  
				document.getElementById('divmail1').innerHTML=""; 
				return true;	
			}  
			else
			{
				document.getElementById('divmail1').innerHTML="Please Enter Valid Agency ID";  
				return false;
			}
		} 
		
		function namevalid()
			{
				var name = /^[a-zA-Z\s-, ]+$/;;
				var val = document.getElementById('vehiclename');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divname').innerHTML="Please Enter Valid Vehicle Name";
					return false;
				}  
				else
				{
					document.getElementById('divname').innerHTML="";
					return true;
				}  
			}
			
			function vno()
			{
				var name = /^[A-Z]{2}[0-9]{2}[a-zA-Z]{2}[0-9]{4}$/;
				var val = document.getElementById('vehicleno');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divno').innerHTML="Please Enter Valid Vehicle No";
					return false;
				}  
				else
				{
					document.getElementById('divno').innerHTML="";
					return true;
				}  
			}
			
			function seatnum()
			{
				var price= /^[1-9]+[0-9]$/;
				var val=document.getElementById('priceperkm');
				if(price.test(val.value) == false)
				{
					document.getElementById('sno').innerHTML="Fill the data..";
					return false;
				}
				else
				{	
					document.getElementById('sno').innerHTML="";
					return true;
				}
				
			}
			function checkbox(val)
			{
			
				if (val.checked == false)
				{
					document.getElementById('divcheck').innerHTML="Please Select Vehicle Permission.";
					return false;
				}
				else
				{	document.getElementById('divcheck').innerHTML="";
					return true;
				}
				
			}
			function checkbox1(val)
			{
			
				if (val.checked == false)
				{
					document.getElementById('divcheck1').innerHTML="Please Select Vehicle Permission.";
					return false;
				}
				else
				{	document.getElementById('divcheck1').innerHTML="";
					return true;
				}
				
			}
	</script>
</head>

<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list"></i>
              				<h3> Vehicles Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
                    					
										
										<?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        <?php } ?>
                                        
                <form action="#" method="post" enctype="multipart/form-data">
                        
                    
                        
                     <table cellpadding="10px" >
                     	                                        
                        <tr>    
                         	<td>Agency Email ID</td>
                         	<td><input type="text" name="agencyid" id="agencyid" placeholder="Enter Agency Id" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["agency_id"]; ?>"<?php } ?> onBlur="validmail1(this.value)"/></td>
                            <td><span id="divmail1" style="color:#930 !important"> *</span></td>
                  		</tr>                                            
                        
                        <tr>
                        	<td>Vehicle Name</td>
                        	<td><input type="text" name="vehiclename" id="vehiclename" placeholder="Enter Vehicle Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["v_name"]; ?>"<?php } ?> onBlur="namevalid()"/></td>
                            <td><span id="divname" style="color:#930 !important"> *</span></td>
                        </tr>                    
                        
                        <tr>
                        <td>Vehicle Type</td>
                        <td><select name="vehicletype"  >
                    						<option value="" <?php if(isset($ERows)) { ?><?php } ?>> Select Vehicle Type</option>
                    						<option value="twowheeler" <?php if(isset($ERows)){ if($ERows["v_type"] == "twowheeler") { ?> selected="selected"<?php } } ?>> Two Wheeler</option>
                    						<option value="fourwheeler" <?php if(isset($ERows)){ if($ERows["v_type"] == "fourwheeler") { ?> selected="selected" <?php } } ?>> Four Wheeler</option>
                    						</select>
                        </td>
                        </tr>                                           
                        
                        <tr>
                        <td>Vehicle No</td> 
                        <td><input type="text" name="vehicleno" id="vehicleno" placeholder="Enter Vehicle No" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["v_no"]; ?>"<?php } ?> onBlur="vno()"/></td>
                        <td><span id="divno" style="color:#930 !important"> *</span></td>
                        </tr>
                             
                        <tr>
                        	<td>Perice Per KM</td>
                            <td><input type="number" name="priceperkm" id="priceperkm" placeholder="Enter price per km" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["price_per_km"]; ?>"<?php } ?> onBlur="seatnum()"/></td>
                            <td><span id="sno" style="color:#930 !important"> *</span></td>
                        </tr>
                        
                        <tr>
                        <td>Vehicle Permission</td>
                        <td><input type="radio" name="vehiclepermission" id="vehiclepermission" value="yes" <?php if(isset($ERows)){ if($ERows["v_permission"] == "yes") { ?> checked="checked" onBlur="checkbox(this.value)" <?php } } ?> />Yes
                        <input type="radio" name="vehiclepermission" id="vehiclepermission" onBlur="checkbox(this.value)" value="no" <?php if(isset($ERows)){ if($ERows["v_permission"] == "no") { ?> checked="checked" <?php } } ?>/>No</td>
                        <td><span id="divcheck" style="color:#930 !important"> *</span></td>
                        </tr>
                        
                        <tr>
                        <td>Vehicle Image</td>
                        <td><input type="file" name="vimg" />
                        </tr>
                        
                        <td>Is Available</td>
                        <td><input type="radio" name="isavailable" id="isavailable" value="yes" onBlur="checkbox1(this.value)"<?php if(isset($ERows)){ if($ERows["is_available"] == "yes") { ?> checked="checked" <?php } } ?>/>Yes
                            <input type="radio" name="isavailable" id="isavailable" value="no"  onBlur="checkbox1(this.value)"<?php if(isset($ERows)){ if($ERows["is_available"] == "no") { ?> checked="checked" <?php } } ?> />No</td>
                            <td><span id="divcheck1" style="color:#930 !important"> *</span></td>
                        </tr>    
                        
                       
                       
                       	<tr>
            	<td></td>
            	<td>
				<?php if(isset($ERows)){ ?>
                			<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?></td>
            </tr>
                        </table>
                        </form>
                        
                        <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Vehicles</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Agency Id</th>
                                                <tH>Vehicle Name</tH>
                                                <th>Vehicle Type</th>
                                                <th>Vehicle No</th>
                                                <th>Price Per KM</th>
                                                <th>Vehicle Permission</th>
                                                <th>Vehicle Image</th>
                                              
                                                <th>Available Status</th>
                                                <th>Upload Date</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["v_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["v_id"]); ?>" class="btn btn-small btn-danger" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["v_name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["v_id"]; ?></td>
                                                <td><?php echo $Rows["agency_id"]; ?></td>
                                                <td><?php echo $Rows["v_name"]; ?></td>
                                                <td><?php echo $Rows["v_type"]; ?></td>
                                                <td><?php echo $Rows["v_no"]; ?></td>
                                                <td><?php echo $Rows["price_per_km"]; ?></td>
                                                <td><?php echo $Rows["v_permission"]; ?></td>
                                                <td><?php echo $Rows["vimg"]; ?></td>
                                                
                                                <td><?php echo $Rows["is_available"]; ?></td>
                                                <td><?php echo $Rows["upload_date"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>

                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
     <?php include("Include/footer.php"); ?>
     <script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

   </body>
</html>
          