


<?php
	require("include/sessionchecker.php");
?>

<?php

require("dbConfig/dbConfig.php");

if(isset($_POST["Submit"]))
{
	$name = $_POST["name"];
	
	$str = "INSERT INTO tbl_staff(StaffName) VALUES('$name')";
	mysql_query($str) or die("Error: Insert query problem");
	header("location:staff.php?msg=Record Inserted sucessfully");
}

if(isset($_POST["editbtn"]))
{
	$Id = $_POST["edId"];
	$name = $_POST["name"];
	
	$str = "UPDATE tbl_staff SET StaffName='$name' WHERE StaffId='$Id'";
	mysql_query($str) or die("Error: Update query problem");
	header("location:staff.php?msg=Record Updated sucessfully");
}


if(isset($_GET["delId"]))
{
	$Id = base64_decode($_GET["delId"]);
	$str = "DELETE FROM tbl_staff WHERE StaffId='$Id'";
	mysql_query($str) or die("Error: Insert query problem");	
	header("location:staff.php?msg=Record Deleted sucessfully");
}

$selstr = "SELECT * FROM tbl_staff";
$Data = mysql_query($selstr) or die("Error: Select Query problem");
$num = mysql_num_rows($Data);

	
if(isset($_GET["edId"]))
{
	$Id = base64_decode($_GET["edId"]);
	$str = "SELECT * FROM tbl_staff WHERE StaffId='$Id'";
	$Edata=mysql_query($str) or die("Error:  query problem");
	$ERows = mysql_fetch_assoc($Edata);
}
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list-alt"></i>
              				<h3> Staff Details	</h3>
            			</div>
            <!-- /widget-header -->
        				<div class="widget-content">
             				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                      					<div class="stats" align="center">
                    	
                        				<?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        <?php } ?>
                        
                        		<form action="" method="post" >
                          
                           
                             <table cellpadding="10px">
                             	
                                <tr>
                                    <td>Staff Name</td>
                                    <td><input type="text" name="name" id="name" placeholder="Enter Admin Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["CatName"]; ?>"<?php } ?> /></td>
                                   <td><span id="divname" style="color:#930 !important"> *</span></td>
                                    
                                </tr>
                  <tr>
            		<td></td>
            		<td>
                    <?php if(isset($ERows)){ ?>
                    <input type="submit" name="editbtn" value="Update" class="btn-primary btn-large">
                    <input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    <?php } else { ?>
                    <input type="submit" name="Submit" class="btn-primary btn-large" />
                    <?php } ?>
                    </td>
            	  </tr>
                                         </table>
                                        </form>
                                        <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Admin</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                                <th>Staff Name</th>
                                                <th>Date Time</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["StaffId"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["StaffId"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["StaffName"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                                <td><?php echo $Rows["StaffName"]; ?></td>
                                                <td><?php echo $Rows["StaffDateTime"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>
 </body>
</html>
          