<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css">
<form method="post" action="#">
	<div class="">
		<div class="widget-content">
			<div class="widget-header">
				<div class="widget-nopad">
					<div class="widget-plain">
						<div class="widget-table" id="">
                        <input type="text">
                        
						</div>
                    </div>
                </div>
            </div>
        </div> 
    </div> 
              
</form>

