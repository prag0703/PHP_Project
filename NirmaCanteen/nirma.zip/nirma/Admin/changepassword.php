<?php
	
	@include("session_Checker.php");

	require("dbConfig/dbConfig.php");


	if(isset($_POST["submit"]))
	{
		$password = $_POST["old_pass"];
		$sel = "SELECT * FROM admin WHERE AId='".$_SESSION["AId"]."' and Password='".$password."'";
		$data = mysql_query($sel);
		$password = $_POST["new_pass"];
		if($data!=0)
		{
			$Change = "UPDATE admin SET Password='$password' WHERE AId='".$_SESSION["AId"]."'";
			$Obj->NonQuery($Change);
			echo $Obj->Redirect("changepassword.php","Your password has been changed successfully");
		}
		else
		{
			echo $Obj->Redirect("changepassword.php","Your Old Password Not Matched");
		}
	}
	
?>
<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>Nirma Canteen Admin</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/pages/signin.css" rel="stylesheet" type="text/css">

</head>

<body>
	
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.html">
				ASIAN DENTAL
			</a>		
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

<script type="text/javascript">

function validate()
{
	
	var old_pass = document.getElementById("old_pass");
	if(old_pass.value=="")
	{
		alert("Please enter your current password");
		old_pass.focus();
		return false;
	}
	var new_pass = document.getElementById("new_pass");
	if(new_pass.value=="")
	{
		alert("Please enter new password");
		new_pass.focus();
		return false;
	}
	var confirm_pass = document.getElementById("confirm_pass");
	if(confirm_pass.value=="")
	{
		alert("Please confirm your password");
		confirm_pass.focus();
		return false;
	}
	var confirm_pass = document.getElementById("confirm_pass");
	var new_pass = document.getElementById("new_pass");
	if(new_pass.value != confirm_pass.value)
	{
		alert("Please enter same password");
		confirm_pass.focus();
		return false;
	}
	return true;
}


</script>


<div class="account-container">
	
	<div class="content clearfix">
		
		<form action="#" method="post">
		
			<h1>Change Password</h1>		
			
			<div class="login-fields">
				
				<p>Please provide your details</p>
				
				<div class="field">
					<label>Old Password</label>
					<input type="password" id="old_pass" name="old_pass" value="" placeholder="Enter Old Password" class="" />
				</div>
                <div class="field">
					<label for="password">New Password</label>
					<input type="password" id="new_pass" name="new_pass" value="" placeholder="Enter New Password" />
				</div>
                <div class="field">
					<label for="password">ReEnter Password</label>
					<input type="password" id="confirm_pass" name="confirm_pass" value="" placeholder="ReEnter Password" />
				</div> <!-- /field -->
				
				
			</div> <!-- /login-fields -->
			
			<div class="login-actions">
				
									
				<button name="submit" id="submit" type="submit" onClick="return validate();" class="button btn btn-success btn-large">Submit</button>
			
			</div> <!-- .actions -->
			
			
			
		</form>
		
	</div> <!-- /content -->
	
</div> <!-- /account-container -->


<div class="login-extra">
	Back to Login Page :- 
	<a href="login.php">Login</a>
</div> <!-- /login-extra -->





<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

</body>

</html>
