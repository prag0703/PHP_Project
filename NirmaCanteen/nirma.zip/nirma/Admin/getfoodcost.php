
 <?php
	//require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	


	if(isset($_GET["FoodId"]))
		{
			$Id = $_GET["FoodId"];
			$str = "SELECT Amount FROM tbl_foodmenu WHERE FoodId='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
			echo $ERows["Amount"];
		}
	else {
			echo "NA";
		}	
?>