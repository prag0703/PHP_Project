<?php
	mysql_connect("localhost","root","") or die("Error: Connection problem");
	mysql_select_db("canteen") or die("Error: No Databse found :-: canteen");
	
?>