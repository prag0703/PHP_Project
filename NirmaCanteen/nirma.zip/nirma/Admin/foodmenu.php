
 <?php
	//require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$category = $_POST["category"];
		$name = $_POST["f_name"];
		$amount = $_POST["amount"];
		$image = $_FILES["fimage"];
		$img = $image["fimage"];
		$NewImg = date("dmyhmsi").".jpg";
		if($image["name"]!="")
		{
			$tmp = $image["tmp_name"];
			move_uploaded_file($tmp, "foodimage/".$NewImg);
			//move_uploaded_file($tmp,"foodimage/".$NewImg);
		}
	
		$isavailable = isset($_POST["isavailable"])?1:o;
		
		$str = "INSERT INTO tbl_foodmenu(CatId,FoodName,Amount,image,IsAvailable) VALUES('$category','$name','$amount','$NewImg','$isavailable')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:foodmenu.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$Id = $_POST["edId"];
		$category = $_POST["category"];
		$name = $_POST["f_name"];
		$amount = $_POST["amount"];
		$isavailable = isset($_POST["isavailable"])?1:o;
		
		$str = "UPDATE tbl_foodmenu SET CatId='$category',FoodName='$name',Amount='$amount',IsAvailable='$isavailable' WHERE FoodId='$Id'";
		
		mysql_query($str) or die("Error: Updated query problem");
		header("location:foodmenu.php?msg=Record Updated sucessfully");
	}
	
		if(isset($_GET["delId"]))
		{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_foodmenu WHERE FoodId='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:foodmenu.php?msg=Record Deleted sucessfully");
		}

		$selstr = "SELECT * FROM tbl_foodmenu INNER JOIN tbl_category ON tbl_foodmenu.CatId = tbl_category.CatId";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

		$selstr1 = "SELECT * FROM tbl_category";
		$CData = mysql_query($selstr1) or die("Error: Select Query problem");
		$Cnum = mysql_num_rows($Data);

	if(isset($_GET["edId"]))
		{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_foodmenu WHERE FoodId='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
		}
		
?><?php  ?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="utf-8">
	<title>Nirma Canteen Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
			rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
        	</head>
	<body>
	<?php include("Include/header.php"); ?>
	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget widget-nopad">
							<div class="widget-header"> <i class="icon-list"></i>
								<h3> Food Menu Details	</h3>
							</div>
				<!-- /widget-header -->
			   <div class="widget-content">
				  <div class="widget big-stats-container">
					<div class="widget-content">
					  <div id="big_stats" class="cf">
						<div class="stats" align="center">
						
						<?php if(isset($_GET["msg"])){?>
												<div class="alert alert-success">
												<?php echo $_GET["msg"]; ?>
												</div> 
											<?php } ?>
							
											
						 <form action="" method="post" enctype="multipart/form-data">
						 
                         <table cellpadding="10px">
                         <tr>
						 <td>Category</td>
						 <td>
                         
                         	<select name="category" id="category" value="">
                        
								<option value="" > Select category</option>
								<?php if($CData !=0 ) { while($SRows=mysql_fetch_array($CData)) {?>
								
								<option value="<?php echo $SRows["CatId"]; ?>" ><?php echo $SRows["CatName"]; ?></option>
								<?php } } ?>
							</select>
						 </td>
						</tr>
                        
						  <tr>
							<td>Food Name</td>
							<td><input type="text" name="f_name" id="f_name" placeholder="Enter Food Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["FoodName"]; ?>"<?php } ?>/></td>
                            
						  </tr>
											 
						 
					  
					  <tr>                          
					  <td>Amount</td>
					  <td><input type="text" name="amount" id="amount" placeholder="Enter Amount" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Amount"]; ?>"<?php } ?> /></td>
                      
					  </tr>
                      <tr>
							<td>Food Image</td>
							<td><input type="file" name="fimage" id="fimage" ></td>
                            
						  </tr>
					  <tr>
                                
                           		<td>Is Available</td>
                           		<td><input type="checkbox" name="isavailable" id="isavailable" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["IsActive"]; ?>" <?php } ?> /></td>
                                <td><span id="divnum" style="color:#930 !important"> *</span></td>
                          
                           </tr>
					<td></td>
					<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
					</td>
				</tr>
					   </table>
											</form>
											
											<div class="widget widget-table action-table">
											<div class="widget-header"> <i class="icon-th-list"></i>
											  <h3>Food Menu Details</h3>
											</div>
											<!-- /widget-header -->
											<div class="widget-content">
										   
											<?php if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													<th>Category Name</th>
													<th>Food Name</th>
                                                    <th>Amount</th>
                                                    <th>Image</th>
                                                    <th>Is Available</th>
												</tr>
												</thead>
												<tbody>
												<?php while($Rows = mysql_fetch_array($Data))
												{
												?>
												<tr>
													<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["FoodId"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["FoodId"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["FoodName"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
													 <td><?php echo $Rows["CatName"]; ?></td>
													<td><?php echo $Rows["FoodName"]; ?></td>
                                                    <td><?php echo $Rows["Amount"]; ?></td>
                                                    <td><img src="foodimage/<?php echo $Rows["image"];?>" height="100px" width="100px"> </td>
													<td><?php if($Rows["IsAvailable"]==1){ ?>
                                                        <img src="img/icn_alert_success.png">
                                                        <?php }else {?>
                                                        <img src="img/icn_alert_error.png">
                                                        <?php } ?>
                                                	</td>
													
												</tr>
												<?php } ?>
												</tbody>
											</table>    
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Customer</div>
                                        <?php } ?>
											
											</div>
											 </div>
										</div>
									</div>
					<!-- /widget-content --> 
					
								</div>
							</div>
						 </div>
					</div>
				</div>
			  </div>
		  </div>
	   </div>
	   <?php include("Include/footer.php"); ?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

	 </body>
	</html>
			  