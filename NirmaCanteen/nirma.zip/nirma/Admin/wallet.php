<?php
	require("include/sessionchecker.php");
	
	require("dbConfig/dbConfig.php");

	if(isset($_POST["Submit"]))
	{
		$Foodname = $_POST["emailId"];
		$quantity = $_POST["amount"];
		$tamount = $_SESSION["AdminId"];
		if($Foodname!="" && $quantity!="")
		{
			$str = "INSERT INTO walletupdate(UserId,Amount,ReceiveBy) VALUES('$Foodname','$quantity','$tamount')";
		
			mysql_query($str) or die("Error: Insert query problem");
			
			$str12 = "SELECT Amount FROM tblwallet WHERE UserId='".$Foodname."'";
			$FData12 = mysql_query($str12) or die("Error: Select Query problem");
			$numRec12 = mysql_num_rows($FData12);
			if($numRec12>0)
			{
				$DataR = mysql_fetch_assoc($FData12);
				$TAmount = $DataR["Amount"]+$quantity;
				$wStr = "UPDATE tblwallet SET Amount='$TAmount' WHERE UserId='$Foodname'";
			}
			else
			{
				$wStr = "INSERT INTO tblwallet(UserId,Amount) VALUES('$Foodname','$quantity')";
			}
			mysql_query($wStr) or die("Error : Update query problem..");
			header("location:wallet.php?msg=Record Inserted sucessfully");
		}
	}
	
	if(isset($_POST["editbtn"]))
	{
		$Id = $_POST["edId"];
		$Foodname = $_POST["fname"];
		$quantity = $_POST["quantity"];
		$tamount = $_POST["tamount"];
		
		$str = "UPDATE tbl_order SET FoodId='$Foodname',Quantity='$quantity',TotalAmount='$tamount' WHERE OrderId='$Id'";
		
		mysql_query($str) or die("Error: Updated query problem");
		header("location:order.php?msg=Record Updated sucessfully");
	}
	
		if(isset($_GET["delId"]))
		{
			$Id = (base64_decode($_GET["delId"]));
			$str = "DELETE FROM tbl_order WHERE OrderId='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:order.php?msg=Record Deleted sucessfully");
		}
		
		$userId = isset($_POST["emailId"])?$_POST["emailId"]:"";
		$selstr = "SELECT W.*,A.name FROM walletupdate as W INNER JOIN tbl_admin as A ON A.a_id=W.ReceiveBy WHERE W.UserId='".$userId."' ORDER BY wuId DESC";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

		$str1 = "SELECT Amount FROM tblwallet WHERE UserId='".$userId."'";
		$FData = mysql_query($str1) or die("Error: Select Query problem");

	if(isset($_GET["edId"]))
		{
			$Id = $_GET["edId"];
			$str = "SELECT * FROM tbl_order WHERE OrderId='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
		}
		
?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="utf-8">
	<title>Nirma Canteen Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
			rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
    <script type="text/javascript">
	function confirmme()
		{
			if(confirm("Are you sure want to delete?"))
			{
				return true;
			}
			return false;
			
		}
		
	function submitForm()
	{
		document.getElementById("WalletForm").submit();
	}
	</script>
	</head>
	<body>
	<?php include("Include/header.php"); ?>
	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget widget-nopad">
							<!--<div class="widget-header"> <i class="icon-list"></i>
								<h3> Order Details	</h3>
							</div>-->
				<!-- /widget-header -->
			   <div class="widget-content">
				  <div class="widget big-stats-container">
					<div class="widget-content">
					  <div id="big_stats" class="cf">
						<div class="stats" align="center">
						
						<?php if(isset($_GET["msg"])){?>
												<div class="alert alert-success">
												<?php echo $_GET["msg"]; ?>
												</div> 
											<?php } ?>
							
											
						 <form action="" method="post" id="WalletForm">
						 
                         <table cellpadding="10px">
						   <tr>
							<td>Email Id</td>
							<td><input type="email" onBlur="submitForm()" name="emailId" id="emailId" placeholder="Enter EmailId" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["FoodName"]; ?>"<?php } else { ?>value="<?php echo isset($userId)?$userId:""; ?>"<?php } ?>/></td>
                            
						  </tr>
						
					  <tr>                          
					  <td>Amount</td>
					  <td><input type="text" name="amount" id="amount" placeholder="Enter Amount" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Amount"]; ?>"<?php } ?> /></td>
                      
					  </tr>				 
						
					  <tr>
					<td></td>
					<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" value="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
					</td>
				</tr>
					   </table>
											</form>
											
											<div class="widget widget-table action-table">
											<div class="widget-header"> <i class="icon-th-list"></i>
											  <h3>Order Details</h3>
											</div>
											<!-- /widget-header -->
											<div class="widget-content">
										   <h3>Wallet Total Amount : 
                                           <?php $numRec1 = mysql_num_rows($FData);
			$TAmount12 = "0.00";
			if($numRec1>0)
			{
				$DataR = mysql_fetch_assoc($FData);
				$TAmount12 = $DataR["Amount"];
			}
			printf("%.2f",$TAmount12);
			?> Rs.
            </h3>
											<?php if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													 <th>Amount</th>
													
                                                    <th>Received Date</th>
												</tr>
												</thead>
												<tbody>
												<?php while($Rows = mysql_fetch_array($Data))
												{
												?>
												<tr>
													<td class="td-actions"><a href="" class="btn btn-small btn-success" onclick="return confirmme()"><i class="btn-icon-only icon-edit"> </i></a> <a href="" class="btn btn-danger btn-small" onClick="return confirmme('Are you sure to Delete : <?php echo $Rows["wuId"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
													<td><?php echo $Rows["Amount"]; ?></td>
													<!-- <td><?php echo $Rows["name"]; ?></td> -->
													<td><?php echo $Rows["GivenDate"]; ?></td>
													
												</tr>
												<?php } ?>
												</tbody>
											</table>    
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Customer</div>
                                        <?php } ?>
											
											</div>
											 </div>
										</div>
									</div>
					<!-- /widget-content --> 
					
								</div>
							</div>
						 </div>
					</div>
				</div>
			  </div>
		  </div>
	   </div>
	   <?php include("Include/footer.php"); ?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>
<script type="text/javascript">

$(document).ready(function(e){
	$("#fname").change(function(e) {
		 var respo = $.ajax({url:"getfoodcost.php?FoodId="+$(this).val(),async:false,cach:false}).responseText;
         $("#amount").val(respo);
         if($("#quantity").val()!="")
         {
        	 var tamount = parseFloat($("#quantity").val()) * parseFloat($("#amount").val()); 
        	$("#tamount").val(tamount);
    	}
	});

	$("#quantity").blur(function(){
        var tamount = parseFloat($(this).val()) * parseFloat($("#amount").val()); 
        $("#tamount").val(tamount);
	});
});

</script>

	 </body>
	</html>
			  