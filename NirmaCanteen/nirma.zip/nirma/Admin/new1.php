<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list-alt"></i>
              				<h3> Admin Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
                    					<form action="#" method="post">
                                        <div class="control-group">
                                        <div class="stats">
                                           Admin ID<input type="text" name="adminid" id="adminid" placeholder="Enter Admin Id"/>
                                        	</div>
                                            <div class="stats">
                                            Admin Name<input type="text" name="adminname" id="adminname" placeholder="Enter Admin Name"/></div>
                                            <div class="stats">
                                            Contact<input type="number" name="admincontact" id="admincontact" placeholder="Enter Admin Contact"/></div>
                      						 <div class="stats">
                                            Email ID<input type="email" name="adminemail" id="adminemail" placeholder="Enter Admin E-mail"/>
                                            </div>
                                             <div class="stats">
                                            Login ID<input type="text" name="adminloginid" id="adminloginid" placeholder="Enter Admin Login ID"/>
                                            </div>
                                            
                                             <div class="stats">
                                            Password<input type="text" name="adminpassword" id="adminpassword" placeholder="Enter Admin Password"/>
                                            </div>     
                                            <div class="stats">
                                            Register Date<input type="date" name="adminregisterdate" id="adminregisterdate" />
                                            </div>
                                            <div class="stats">
                                            Login Date<input type="date" name="adminlogindate" id="adminlogindate" />
                                            </div>                      
                                            
                                            <div class="stats">
                                            <input type="submit" name="Submit" id="submit"/>
                                            </div>
                                        </form>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
 </body>
</html>
          