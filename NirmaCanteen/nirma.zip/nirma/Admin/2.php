<!DOCTYPE html>
<html lang="en">
<head>

<script>

function onlychar(val)
{
	//alert(val.length);
	for(i=0;i<val.length;i++)
	{	
		//alert(i);
		if(val.charAt(i)>=0 && val.charAt(i)<=9)
		{
		document.getElementById('onlychar').innerHTML="Enter only chars..";
		return false;
		}
		else
		{
		document.getElementById('onlychar').innerHTML="";
		return true;
		}
	}
}
function validate() {
    var firstname = document.getElementById("FirstName");
    var alpha = /^[a-zA-Z\s-, ]+$/;  
    if (firstname.value == "") {
        alert('Please enter Name');
        return false;
    }
    else if (!firstname.value.match(alpha)) {
        alert('Invalid ');       
        return false;
   }
   else 
   {
    return true;
   }
}

</script>
<style>
.error {color: #FF0000;}
</style>

<meta charset="utf-8">
<title>Admin Details</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/pages/dashboard.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
 <script type="text/javascript" src=""></script> 
</head>
<body>
<?php include("Include/header.php"); ?>

<?php
// define variables and set to empty values
$admin_idErr = $nameErr = $contactErr = $emailErr = $genderErr = $login_idErr = $passwordErr = $login_dateErr = $register_dateErr = "";
$name = $email = $gender = $comment = $website = "";

 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if (empty($_POST["adminid"])) {
    $admin_idErr = "Admin Id is required";
	
   } 
   else {
     $name = test_input($_POST["adminname"]);
     // check if name only contains letters and whitespace
   	  if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $nameErr = "Only letters and white space allowed"; 
     }
   }
   
   if (isset($_POST["adminemail"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["adminemail"]);
     // check if e-mail address is well-formed
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email format"; 
     }
   }
     
   if (empty($_POST["password"])) {
    $passwordErr="Enter Your Password";
   } else {
     $website = test_input($_POST["ad_registerdate"]);
     // check if URL address syntax is valid
     if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
       $websiteErr = "Invalid URL"; 
     } 
   }

   if (empty($_POST["comment"])) {
     $comment = "";
   } else {
     $comment = test_input($_POST["comment"]);
   }

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = test_input($_POST["gender"]);
   }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list-alt"></i>
              				<h3> Admin Details	</h3>
            			</div>
            <!-- /widget-header -->
        				<div class="widget-content">
             				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                      					<div class="stats" align="center">
                    	
                       <form action="" method="post" name="ad_form">
                          
                           
                             <table>
                             	
                                <tr>
                                    <td>Admin ID</td>
                                    <td><input type="text" name="adminid" id="adminid" placeholder="Enter Admin ID" /> </td>
                                    <td class="onlychar">*<?php echo $admin_idErr;?></td>
                                </tr>
                               	
                                <tr>
                                    <td>Admin Name
                                    </td>
                                    <td><input type="text" name="adminname"  placeholder="Enter Admin Name" onChange="onlychar(this.value);" required/></td><td id="onlychar"></td>
                                                                      
                                </tr>
                           	 
                           		<tr>
                                
                           		<td>Contact</td>
                           		<td><input type="number" name="admincontact" id="admincontact" maxlength="10" placeholder="Enter Admin Contact" /></td>
                           </tr>
                           
                           	<tr>
                            
                           	<td>Email ID</td>
                           	<td><input type="email" name="adminemail" id="adminemail" placeholder="Enter Admin E-mail"/></td>
                           	<td class="error">*<?php echo $emailErr;?></td>
                            </tr>
                            
                            <tr>
                            
                           	<td>Login ID</td>
                           	<td><input type="email" name="loginid" id="loginid" placeholder="Enter Admin Login"/></td>
                           	
                            </tr>
                           
                          
                           
                           <tr>
  							<td>Password</td>
                            <td><input type="text" name="adminpassword" id="adminpassword" placeholder="Enter Admin Password"/></td>
                            <td class="error">*<?php echo $passwordErr;?></td>
   							</tr>
                            <tr>
                            <td>Register Date</td>
                            <td><input type="date" name="ad_registerdate" id="ad_registerdate" required/></td>
                           <td class="error"> *<?php echo $register_dateErr;?></td>
                            </tr>
                            
                            <tr>                
                            <td>Login Date</td>
                            <td><input type="date" name="adminlogindate" id="adminlogindate"  /></td>
                            </tr>
                                                                
                                            
                  <tr>
            		<td></td>
            		<td><input type="submit" name="Submit" id="submit" class="button btn btn-primary btn-large" /></td>
            	  </tr>
                                         </table>
                                        </form>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
 </body>
</html>
          