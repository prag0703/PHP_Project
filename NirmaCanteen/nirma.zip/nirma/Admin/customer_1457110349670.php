
<?php
	require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$name = $_POST["name"];
		$address = $_POST["address"];
		$state = $_POST["state"];
		$city = $_POST["city"];
		$zipcode = $_POST["zipcode"];
		$contact = $_POST["contact"];
		$email = $_POST["email"];
		$loginid = $_POST["loginid"]; 	
		$password = $_POST["password"];
		
		$str = "INSERT INTO tbl_customer(name,address,state,city,zipcode,contact,email_id,Login_id,password) VALUES('$name','$address','$state','$city','$zipcode','$contact','$email','$loginid','$password')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:Customer.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$name = $_POST["c_name"];
		$address = $_POST["c_address"];
		$state = $_POST["c_state"];
		$city = $_POST["c_city"];
		$zipcode = $_POST["c_zipcode"];
		$contact = $_POST["c_contact"];
		$email = $_POST["c_email"];
		$loginid = $_POST["c_loginid"]; 	
		$password = $_POST["c_password"];
		
		$str = "UPDATE tbl_customer SET name='$name',address='$address',state='$state',city='$city',zipcode='$zipcode',contact='$contact',email_id='$email',Login_id='$loginid',password='$password'";
		
		mysql_query($str) or die("Error: Updated query problem");
		header("location:Customer.php?msg=Record Updated sucessfully");
	}
	
		if(isset($_GET["delId"]))
		{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_customer WHERE customer_id='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:Customer.php?msg=Record Deleted sucessfully");
		}

		$selstr = "SELECT * FROM tbl_customer";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

	if(isset($_GET["edId"]))
		{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_customer WHERE customer_id='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
		}
		
?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="utf-8">
	<title>Nirma Canteen Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
			rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
         <script>

function onlychar(val)
    {
	//alert(val.length);
	   //var val = document.getElementById('char');
	for(i=0;i<val.length;i++)
	{	
	//alert(i);
		if(val.charAt(i)>=0 && val.charAt(i)<=9)
		{
		document.getElementById('onlychar').innerHTML="Enter only chars..";
		return false;
		}
		else
		{
		document.getElementById('onlychar').innerHTML="";
		return true;
		}
	}
}

function validate() {
    var firstname = document.getElementById("FirstName");
    var alpha = /^[a-zA-Z\s-, ]+$/;  
    if (firstname.value == "") {
        alert('Please enter Name');
        return false;
    }
    else if (!firstname.value.match(alpha)) {
        alert('Invalid ');       
        return false;
   }
   else 
   {
    return true;
   }
}

function validmail(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail').innerHTML="Please enter valid email";  
		return false;
  	}
} 

function validmail1(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail1').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail1').innerHTML="Please enter valid id";  
		return false;
  	}
} 

function mobilenum()
{
	var mob = /^[1-9]{1}[0-9]{9}$/;
    var val = document.getElementById('mob');
    if (mob.test(val.value) == false) 
		{
			document.getElementById('divnum').innerHTML="Please enter valid mobile number.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divnum').innerHTML="";
			return true;
        }  
} 

function address(val)
{
	if(val== "")
	{
		document.getElementById('add').innerHTML="Must enter address..";
		return false;
	}
	else
	{	
		document.getElementById('add').innerHTML="";
		return true;
	}
}
</script>

	</head>
	<body>
	<?php include("Include/header.php"); ?>
	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget widget-nopad">
							<div class="widget-header"> <i class="icon-list-ol"></i>
								<h3> Customer Details	</h3>
							</div>
				<!-- /widget-header -->
			   <div class="widget-content">
				  <div class="widget big-stats-container">
					<div class="widget-content">
					  <div id="big_stats" class="cf">
						<div class="stats" align="center">
						
						<?php if(isset($_GET["msg"])){?>
												<div class="alert alert-success">
												<?php echo $_GET["msg"]; ?>
												</div> 
											<?php } ?>
							
											
						 <form action="" method="post">
						 
			
						 
						 <table cellpadding="10px">
						 
										   
						  <tr>
							<td>Customer Name</td>
							<td><input type="text" name="name"  placeholder="Enter Customer Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["name"]; ?>"<?php } ?> onblur="onlychar(this.value);"/></td>
                            <td><span id="onlychar" style="color:#930 !important"></span></td>
						  </tr>
											 
						 <tr>
						   <td>Address</td>
						  <td><textarea name="address" name="address"  placeholder="Enter Customer Address"<?php if(isset($ERows)) { ?>value="<?php echo $ERows["name"]; ?>"<?php } ?> onblur="address(this.value);"/></textarea></td>
                            <td><span id="add" style="color:#930 !important"></span></td>
						</tr>
											
						<tr>
						 <td>State</td>
						 <td>
                         
                         <select name="state" value="">
                        
								<option value=" "  <?php if(isset($ERows)) { ?><?php } ?>> Select State</option>
								<option value="Gujarat"  <?php if(isset($ERows)){ if($ERows["state"]=="Gujarat") { ?> selected="selected"<?php } } ?>> Gujarat</option>
								<option value="Maharastra" <?php if(isset($ERows)){ if($ERows["state"]=="Maharastra") { ?> selected="selected"<?php } } ?>>Maharastra</option>
								<option value="Panjab" <?php if(isset($ERows)){ if($ERows["state"]=="Panjab") { ?> selected="selected"<?php } } ?>> Panjab</option>
							 </select>
						 </td>
						</tr>
						
						<tr>
						<td>City</td>
						<td>
						<select name="city" value="">
                        <option value=""> Select City</option>
						<option value="Ahmedabad" <?php if(isset($ERows)){ if($ERows["city"]=="Ahmedabad") { ?> selected="selected"<?php } } ?>> Ahmedabad</option>
						<option value="Surat" <?php if(isset($ERows)){ if($ERows["city"]=="Surat") { ?> selected="selected"<?php } } ?>> Surat</option>
						<option value="Rajkot" <?php if(isset($ERows)){ if($ERows["city"]=="Rajkot") { ?> selected="selected"<?php } } ?>> Rajkot</option>
						</select>
						</td>
						</tr>
					   
					   <tr>                         
					   <td>Zipcode</td>
					   <td><input type="number" name="zipcode" id="zipcode" placeholder="Enter City Zipcode" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["zipcode"]; ?>"<?php } ?>/></td>
					   </tr>
					  
					  <tr>
                      		<td>Contact</td>
                           		<td><input type="number" type="text" name="mob" id="mob" placeholder="Enter Admin Contact" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["contact"]; ?>" <?php } ?> onblur="mobilenum();"/></td>
                           <td><span id="divnum" style="color:#930 !important"></span></td>
                           </tr>
                           
					   
					  	<tr>
                           	<td>Email ID </td>
                           	<td><input type="email" name="email"  placeholder="Enter Admin E-mail" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["email_id"]; ?>" <?php } ?>  onBlur="validmail(this.value);"/></td>
                            <td><span id="divmail" style="color:#930 !important"></span></td>
                            </tr>
                            
					  <tr>	
                      	<td>Login ID</td>
                           	<td><input type="email" name="loginid" placeholder="Enter Admin Login" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["login_id"]; ?>" <?php } ?> onBlur="validmail1(this.value);" /></td>
                             <td><span id="divmail1" style="color:#930 !important"></span></td>
                           	
                            </tr> 
					   
					   <tr>                         
					   <td>Password</td>
					   <td><input type="password" name="password" id="password" placeholder="Enter Customer Password" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["password"]; ?>"<?php } ?>/></td>
					   </tr>
					   
					   
					  <tr>
					<td></td>
					<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
					</td>
				</tr>
					   </table>
											</form>
											
											<div class="widget widget-table action-table">
											<div class="widget-header"> <i class="icon-th-list"></i>
											  <h3>Customer</h3>
											</div>
											<!-- /widget-header -->
											<div class="widget-content">
										   
											<?php if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													<th>Id</th>
													<th>Customer Name</th>
                                                    <th>Address</th>
                                                    <th>State</th>
                                                    <th>City</th>
                                                    <th>Zipcode</th>
                                                    <th>Contact</th>
													<th>Email Id</th>
													<th>Login Id</th>
													<th>Password</th>
													<th>Register Date</th>
												</tr>
												</thead>
												<tbody>
												<?php while($Rows = mysql_fetch_array($Data))
												{
												?>
												<tr>
													<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["customer_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["customer_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
													<td><?php echo $Rows["customer_id"]; ?></td>
													<td><?php echo $Rows["name"]; ?></td>
                                                    <td><?php echo $Rows["address"]; ?></td>
                                                    <td><?php echo $Rows["state"]; ?></td>
                                                    <td><?php echo $Rows["city"]; ?></td>
                                                    <td><?php echo $Rows["zipcode"]; ?></td>
													<td><?php echo $Rows["contact"]; ?></td>
													<td><?php echo $Rows["email_id"]; ?></td>
													<td><?php echo $Rows["Login_id"]; ?></td>
													<td><a href="#" title="<?php echo $Rows["password"]; ?>">********</a></td>
													<td><?php echo $Rows["register_date"]; ?></td>
												</tr>
												<?php } ?>
												</tbody>
											</table>    
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Customer</div>
                                        <?php } ?>
											
											</div>
											 </div>
										</div>
									</div>
					<!-- /widget-content --> 
					
								</div>
							</div>
						 </div>
					</div>
				</div>
			  </div>
		  </div>
	   </div>
	   <?php include("Include/footer.php"); ?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

	 </body>
	</html>
			  