
function adminvalidation()
	{
    	var admin_id =document.admin.admin_id;

	}