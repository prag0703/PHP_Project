<?php
mysql_connect("localhost","root","") or die ("error in connection");
mysql_select_db("db_dreamjourney") or die ("error in database");
?>