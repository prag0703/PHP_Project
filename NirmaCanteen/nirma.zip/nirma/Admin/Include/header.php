
 <script language="javascript" type="text/javascript">
	function confirmMe(msg)
	{
		if(confirm(msg))
		{
			return true;
		}
		return false;
	}
	
	
	
</script>

<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </a><a class="brand" href="deshboard.php"> Nirma Canteen </a>
                   <ul class="nav pull-right">
                      <ul class="dropdown-menu">
              
            </ul>
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-user"></i> <?php //echo $_SESSION["Name"]; ?><b class="caret"></b></a>
            <ul class="dropdown-menu">
            
              <li><a href="logout.php">Logout</a></li>
            </ul>
	</li>
</ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /navbar-inner --> 
</div>
<!-- /navbar -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
     <?php $url = ltrim(strrchr($_SERVER['PHP_SELF'],"/"),"/"); ?>
        <li <?php echo $url == "deshboard.php"?'class="active"':""; ?>><a href="deshboard.php"><i class="icon-dashboard"></i><span>Dashboard</span> </a> </li>
        <li <?php echo $url == "category.php"?'class="active"':""; ?>><a href="category.php"><i class="icon-list-alt"></i><span>Category</span> </a> </li>
        <li <?php echo $url == "foodmenu.php"?'class="active"':""; ?>><a href="foodmenu.php"><i class="icon-list-alt"></i><span>Food Menu</span> </a></li>
        <li <?php echo $url == "order.php"?'class="active"':""; ?>><a href="order.php"><i class="icon-list-alt"></i><span>Order</span> </a></li>
        <li <?php echo $url == "user.php"?'class="active"':""; ?>><a href="user.php"><i class="icon-list-alt"></i><span>User</span> </a> </li>
        <li <?php echo $url == "wallet.php"?'class="active"':""; ?>><a href="wallet.php"><i class="icon-list-alt"></i><span>Wallets</span> </a> </li>
        <li <?php echo $url == "staff.php"?'class="active"':""; ?>><a href="staff.php"><i class="icon-list-alt"></i><span>Staff</span> </a> </li>
       <!--  <li <?php echo $url == "changepassword1.php"?'class="active"':""; ?>><a href="changepassword1.php"><i class="icon-list-alt"></i><span>Change Password</span> </a> </li> -->
        <li <?php echo $url == "logout.php"?'class="active"':""; ?>><a href="logout.php"><i class="icon-list-alt"></i><span>Logout</span> </a> </li>
        
          </ul>
        </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
</div>