<!-- Validation -->

<?php 
// define variables and set to empty values
$admin_idErr = $nameErr = $contactErr = $emailErr = $genderErr = $login_idErr = $passwordErr = $login_dateErr = $register_dateErr = "";
$name = $email = $gender = $comment = $website = "";

 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if ((isset($_POST["adminname"])== " ")) {
    $nameErr = "Admin Name is required";

   } else {
     $name = test_input($_POST["adminname"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $nameErr = "Only letters and white space allowed"; 
     }
   }
   
   if (isset($_POST["adminemail"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["adminemail"]);
     // check if e-mail address is well-formed
     if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email format"; 
     }
   }
     
   if (empty($_POST["password"])) {
    $passwordErr="Enter Your Password";
   } else {
     $website = test_input($_POST["ad_registerdate"]);
     // check if URL address syntax is valid
     if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
       $websiteErr = "Invalid URL"; 
     } 
   }

   if (empty($_POST["comment"])) {
     $comment = "";
   } else {
     $comment = test_input($_POST["comment"]);
   }

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = test_input($_POST["gender"]);
   }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

?>



<?php
	require("include/sessionchecker.php");
?>

<?php

require("dbConfig/dbConfig.php");

if(isset($_POST["Submit"]))
{
	$name = $_POST["name"];
	$contact = $_POST["mob"];
	$email = $_POST["email"];
	$login = $_POST["loginid"];
	$password = $_POST["password"];
	
	$str = "INSERT INTO tbl_admin(name,contact,email_id,login_id,password) VALUES('$name','$contact','$email','$login','$password')";
	mysql_query($str) or die("Error: Insert query problem");
	header("location:Admin.php?msg=Record Inserted sucessfully");
}

if(isset($_POST["editbtn"]))
{
	$name = $_POST["name"];
	$contact = $_POST["mob"];
	$email = $_POST["email"];
	$login = $_POST["loginid"];
	$password = $_POST["password"];
	$Id = $_POST["edId"];
	
	$str = "UPDATE tbl_admin SET name='$name',contact='$contact',email_id='$email',login_id='$login',password='$password' WHERE a_id='$Id'";
	mysql_query($str) or die("Error: Update query problem");
	header("location:Admin.php?msg=Record Updated sucessfully");
}


if(isset($_GET["delId"]))
{
	$Id = base64_decode($_GET["delId"]);
	$str = "DELETE FROM tbl_admin WHERE a_id='$Id'";
	mysql_query($str) or die("Error: Insert query problem");	
	header("location:Admin.php?msg=Record Deleted sucessfully");
}

$selstr = "SELECT * FROM tbl_admin";
$Data = mysql_query($selstr) or die("Error: Select Query problem");
$num = mysql_num_rows($Data);

	
if(isset($_GET["edId"]))
{
	$Id = base64_decode($_GET["edId"]);
	$str = "SELECT * FROM tbl_admin WHERE a_id='$Id'";
	$Edata=mysql_query($str) or die("Error:  query problem");
	$ERows = mysql_fetch_assoc($Edata);
}
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Details</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
 
 <script>

function onlychar(val)
    {
	//alert(val.length);
	   //var val = document.getElementById('char');
	for(i=0;i<val.length;i++)
	{	
	//alert(i);
		if(val.charAt(i)>=0 && val.charAt(i)<=9)
		{
		document.getElementById('onlychar').innerHTML="Enter only chars..";
		return false;
		}
		else
		{
		document.getElementById('onlychar').innerHTML="";
		return true;
		}
	}
}

function validate() {
    var firstname = document.getElementById("FirstName");
    var alpha = /^[a-zA-Z\s-, ]+$/;  
    if (firstname.value == "") {
        alert('Please enter Name');
        return false;
    }
    else if (!firstname.value.match(alpha)) {
        alert('Invalid ');       
        return false;
   }
   else 
   {
    return true;
   }
}

function validmail(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail').innerHTML="Please enter valid email";  
		return false;
  	}
} 

function validmail1(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail1').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail1').innerHTML="Please enter valid id";  
		return false;
  	}
} 

function mobilenum()
{
	var mob = /^[1-9]{1}[0-9]{9}$/;
    var val = document.getElementById('mob');
    if (mob.test(val.value) == false) 
		{
			document.getElementById('divnum').innerHTML="Please enter valid mobile number.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divnum').innerHTML="";
			return true;
        }  
} 
</script>

<style>
.error {color: #FF0000;}
</style>

 
 
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list-alt"></i>
              				<h3> Admin Details	</h3>
            			</div>
            <!-- /widget-header -->
        				<div class="widget-content">
             				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                      					<div class="stats" align="center">
                    	
                        				<?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        <?php } ?>
                        
                        					<form action="" method="post" name="admin">
                          
                           
                             <table cellpadding="10px">
                             	
                                <tr>
                                    <td>Admin Name</td>
                                    <td><input type="text" name="name" id="adminname" placeholder="Enter Admin Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["name"]; ?>"<?php } ?>  onblur="onlychar(this.value);"/></td>
                                    <td><span id="onlychar" style="color:#930 !important"></span></td>
                                  <td style="color:#F00;"><?php echo $nameErr;?></td> 
                                </tr>
                           	 
                           		<tr>
                                
                           		<td>Contact</td>
                           		<td><input type="number" type="text" name="mob" id="mob" placeholder="Enter Admin Contact" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["contact"]; ?>" <?php } ?> onblur="mobilenum();"/></td>
                           <td><span id="divnum" style="color:#930 !important"></span></td>
                           </tr>
                           
                           	<tr>
                            
                           	<td>Email ID </td>
                           	<td><input type="email" name="email"  placeholder="Enter Admin E-mail" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["email_id"]; ?>" <?php } ?>  onBlur="validmail(this.value);"/></td>
                            <td><span id="divmail" style="color:#930 !important"></span></td>
                           	<td class="error">*<?php echo $emailErr;?></td>
                            </tr>
                            
                            <tr>
                           	<td>Login ID</td>
                           	<td><input type="email" name="loginid" placeholder="Enter Admin Login" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["login_id"]; ?>" <?php } ?> onBlur="validmail1(this.value);" /></td>
                             <td><span id="divmail1" style="color:#930 !important"></span></td>
                           	
                            </tr>
                           
                          
                           
                           <tr>
  							<td>Password</td>
                            <td><input type="password" name="password" id="adminpassword" placeholder="Enter Admin Password" <?php if(isset($ERows)){ ?> value="<?php echo $ERows["password"]; ?>" <?php } ?>/></td>
   							</tr>
                            <tr>
                                            
                  <tr>
            		<td></td>
            		<td>
                    <?php if(isset($ERows)){ ?>
                    <input type="submit" name="editbtn" value="Update" class="btn-primary btn-large">
                    <input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    <?php } else { ?>
                    <input type="submit" name="Submit" class="btn-primary btn-large" />
                    <?php } ?>
                    </td>
            	  </tr>
                                         </table>
                                        </form>
                                        <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Admin</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Admin Name</th>
                                                <tH>Contact</tH>
                                                <th>Email Id</th>
                                                <th>Login Id</th>
                                                <th>Password</th>
                                                <th>Register Date</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["a_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["a_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["a_id"]; ?></td>
                                                <td><?php echo $Rows["name"]; ?></td>
                                                <td><?php echo $Rows["contact"]; ?></td>
                                                <td><?php echo $Rows["email_id"]; ?></td>
                                                <td><?php echo $Rows["login_id"]; ?></td>
                                                <td><a href="#" title="<?php echo $Rows["password"]; ?>">********</a></td>
                                                <td><?php echo $Rows["register_date"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>
 </body>
</html>
          