
<?php
	require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$cid = $_POST["tr_cid"];
		$tid = $_POST["tr_tid"];
		$noofdays = $_POST["tr_no_of_days"];
		$noofseat = $_POST["tr_no_of_seat"];
		$paymenttterm = $_POST["tr_paymentterm"];
		$isconfirm = $_POST["tr_isconfirm"];
		$cdate = $_POST["tr_cdate"];
		
		
		
		$str = "INSERT INTO tbl_trrequest(customer_id,tour_id,no_of_days,no_of_seat,payment_term,is_confirm,confirm_date) VALUES('$cid','$tid','$noofdays','$noofseat','$paymenttterm','$isconfirm','$cdate')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourrequest.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$cid = $_POST["tr_cid"];
		$tid = $_POST["tr_tid"];
		$noofdays = $_POST["tr_no_of_days"];
		$noofseat = $_POST["tr_no_of_seat"];
		$paymenttterm = $_POST["tr_paymentterm"];
		$isconfirm = $_POST["tr_isconfirm"];
		$cdate = $_POST["tr_cdate"];
		
		
		
		$str = "UPDATE tbl_trrequest SET customer_id='$cid',tour_id='$tid',no_of_days='$noofdays',no_of_seat='$noofseat',payment_term='$paymenttterm',is_confirm='$isconfirm',confirm_date='$cdate'";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourrequest.php?msg=Record Updated sucessfully");
	}
	
		$selstr = "SELECT * FROM tbl_trrequest";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);
	
	if(isset($_GET["delId"]))
			{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_trrequest WHERE tr_id='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:tourrequest.php?msg=Record Deleted sucessfully");
			}
		
		if(isset($_GET["edId"]))
			{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_trrequest WHERE tr_id='$Id'";
			$Edata=mysql_query($str) or die("Error: Update query problem");	
			$ERows=mysql_fetch_assoc($Edata);
			}
	
	
	?>
	
	
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list"></i>
              				<h3> Tour Request Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
            
            					<?php if(isset($_GET["msg"])){?>
                                <div class="alert alert-success">
                                <?php echo $_GET["msg"]; ?>
                                </div> 
                                <?php } ?>
                                
                                
            	<form action="#" method="post">
            	<table cellpadding="10px">
               
                <tr>
                <td>Customer ID</td>
                <td><input type="text" name="tr_cid" placeholder="Customer ID" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["customer_id"]; ?>"<?php } ?>/>	</td>
                </tr>
					
				<tr>
                <td>Tour ID</td>
                <td><input type="text" name="tr_tid" placeholder="Enter Tour ID" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["tour_id"]; ?>"<?php } ?>/></td>
				</tr>
                
                <tr>
                <td>No Of Days</td>
                <td><input type="number" name="tr_no_of_days" placeholder=" Enter No Of Days" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["no_of_days"]; ?>"<?php } ?>/></td>
                </tr>
				  
                  <tr>
                  <td>No Of Seat</td>
                  <td><input type="number" name="tr_no_of_seat" placeholder="Enter No Of Seat" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["no_of_seat"]; ?>"<?php } ?>/></td>
                  </tr>
                  
                  <tr>
                <td>Payment Term</td>
                <td><input type="text" name="tr_paymentterm" placeholder="payment Term" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["payment_term"]; ?>"<?php } ?>/></td>
                </tr>
                
                <tr>
 					<td>Is Confirm</td>
                    <td><input type="radio" name="tr_isconfirm" value="yes" <?php if(isset($ERows)){ if($ERows["is_confirm"] == "yes") { ?> checked="checked" <?php } } ?>/>Yes
                    	<input type="radio" name="tr_isconfirm" value="no" <?php if(isset($ERows)){ if($ERows["is_confirm"] == "no") { ?> checked="checked" <?php } } ?> />No</td>
                 </tr>    
                 
                 <tr>
                 	<td>Confirm Date</td>
                    <td><input type="date" name="tr_cdate" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["confirm_date"]; ?>"<?php } ?>></td>
                 </tr>
                 
			<tr>
            	<td></td>
            	<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
				</td>
            </tr>
            </table>
			</form>
            
             <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Tour Request</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Customer ID</th>
                                                <tH>Tour ID</tH>
                                                <th>No Of Days</th>
                                                <th>No of Seat</th>
                                                <th>Payment Term</th>
                                                <th>Is Confirm</th>
                                                <th>Request Date</th>
                                                <th>Confirm Date</th>
                                                
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["tr_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["tr_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["customer_id"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["tr_id"]; ?></td>
                                                <td><?php echo $Rows["customer_id"]; ?></td>
                                                <td><?php echo $Rows["tour_id"]; ?></td>
                                                <td><?php echo $Rows["no_of_days"]; ?></td>
                                                <td><?php echo $Rows["no_of_seat"]; ?></td>
                                                <td><?php echo $Rows["payment_term"]; ?></td>
                                                <td><?php echo $Rows["is_confirm"]; ?></td>
                                                <td><?php echo $Rows["request_date"]; ?></td>
                                                <td><?php echo $Rows["confirm_date"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                       
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
   <script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

 </body>
</html>
          