<?php
	require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$fname = $_POST["fname"];
		$lname = $_POST["lname"];
		$address = $_POST["address"];
		$contact = $_POST["contact"];
		$gender = $_POST["gender"];
		$email = $_POST["email"]; 	
		$password = $_POST["password"];
		$cpassword = $_POST["cpassword"];
		
		$str = "INSERT INTO tbl_customer (Fname,Lname,Address,Contact,Gender,Emailid,Password,Cpassword) VALUES('$fname','$lname','$address','$contact','$gender','$email','$password','$cpassword')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:user.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$Id=$_POST["edId"];
		$fname = $_POST["fname"];
		$lname = $_POST["lname"];
		$address = $_POST["address"];
		$contact = $_POST["contact"];
		$gender = $_POST["gender"];
		$email = $_POST["email"]; 	
		$password = $_POST["password"];
		$cpassword = $_POST["cpassword"];
		
		$str = "UPDATE tbl_customer SET Fname='$fname',Lname='$lname',Address='$address',Contact='$contact',Gender='$gender',Emailid='$email',Password='$password',Cpassword='$cpassword' WHERE CustId='$Id'";
		
		mysql_query($str) or die("Error: Updated query problem");
		header("location:user.php?msg=Record Updated sucessfully");
	}
	
		if(isset($_GET["delId"]))
		{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_customer WHERE CustId='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:user.php?msg=Record Deleted sucessfully");
		}

		$selstr = "SELECT * FROM tbl_customer";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

	if(isset($_GET["edId"]))
		{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_customer WHERE CustId='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");
			$ERows = mysql_fetch_assoc($Edata);
		}
		
?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="utf-8">
	<title>Nirma Canteen Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
			rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
  
        
        
	</head>
	<body>
	<?php include("Include/header.php"); ?>
	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget widget-nopad">
							<div class="widget-header"> <i class="icon-list"></i>
								<h3> Customer Details	</h3>
							</div>
				<!-- /widget-header -->
			   <div class="widget-content">
				  <div class="widget big-stats-container">
					<div class="widget-content">
					  <div id="big_stats" class="cf">
						<div class="stats" align="center">
						
						<?php if(isset($_GET["msg"])){?>
												<div class="alert alert-success">
												<?php echo $_GET["msg"]; ?>
												</div> 
											<?php } ?>
							
											
						 <form action="" method="post">
						 
                         <table cellpadding="10px">
						  <tr>
							<td>First Name</td>
							<td><input type="text" name="fname" id="fname" placeholder="Enter First Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Fname"]; ?>"<?php } ?> onBlur="namevalid()"/></td>
                            
						  </tr>
                          
                          <tr>
							<td>Last Name</td>
							<td><input type="text" name="lname" id="Lname" placeholder="Enter Last Name" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Fname"]; ?>"<?php } ?> onBlur="namevalid()"/></td>
                            
						  </tr>
											 
						 <tr>
						   <td>Address</td>
						  <td><textarea name="address"  id="address" placeholder="Enter User Address" onBlur="address(this.value)"><?php if(isset($ERows)){?><?php echo $ERows["Address"]; ?><?php } ?></textarea>
                          </td>
                          
						</tr>
					  <tr>                          
					  <td>Contact</td>
					  <td><input type="number" name="contact" id="contact" placeholder="Enter Customer Contact" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Contact"]; ?>"<?php } ?> onBlur="mobilenum()"/></td>
                      <td><span id="divnum" style="color:#930 !important"> *</span></td>
					  </tr>
                      
                      <tr>                          
					  <td>Gender</td>
					  <td><input type="radio" name="gender" id="male" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Gender"]; ?>"<?php } ?> onBlur="mobilenum()"/>Male
                      <input type="radio" name="gender" id="female" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Gender"]; ?>"<?php } ?> onBlur="mobilenum()"/>Female
                      </td>
                      <td><span id="divnum" style="color:#930 !important"> *</span></td>
					  </tr>
					   
					   <tr>
					   <td>Email ID</td>
					   <td><input type="email" name="email" id="email" placeholder="Enter Customer E-mail" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["Emailid"]; ?>"<?php } ?> onBlur="validmail()"/></td>
                       <td><span id="divmail" style="color:#930 !important"> *</span></td>
					   </tr>
					   
					   <tr>                         
					   <td>Password</td>
					   <td><input type="password" name="password" id="password" placeholder="Enter Customer Password" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["password"]; ?>"<?php } ?>/></td>
					   </tr>
                       
                       <tr>                         
					   <td>Confirm Password</td>
					   <td><input type="password" name="cpassword" id="cpassword" placeholder="Enter Customer Password" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["password"]; ?>"<?php } ?>/></td>
					   </tr>
					   
					   
					  <tr>
					<td></td>
					<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
					</td>
				</tr>
					   </table>
											</form>
											
											<div class="widget widget-table action-table">
											<div class="widget-header"> <i class="icon-th-list"></i>
											  <h3>Customer</h3>
											</div>
											<!-- /widget-header -->
											<div class="widget-content">
										   
											<?php if($num > 0) { ?>
											  <table class="table table-striped table-bordered">
												<thead>
											   <tr>
													<th>ACTIONS</th>
													<th>First Name</th>
                                                    <th>Last Name</th>
                                                    <th>Address</th>
                                                    <th>Contact</th>
                                                    <th>Gender</th>
													<th>Email Id</th>
													<th>Password</th>
													<th>Confirm Password</th>
												</tr>
												</thead>
												<tbody>
												<?php while($Rows = mysql_fetch_array($Data))
												{
												?>
												<tr>
													<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["CustId"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["CustId"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["Fname"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
													<td><?php echo $Rows["Fname"]; ?></td>
													<td><?php echo $Rows["Lname"]; ?></td>
                                                    <td><?php echo $Rows["Address"]; ?></td>
													<td><?php echo $Rows["Contact"]; ?></td>
                                                    <td><?php echo $Rows["Gender"]; ?></td>
													<td><?php echo $Rows["Emailid"]; ?></td>
													<td><a href="#" title="<?php echo $Rows["Password"]; ?>">********</a></td>
													<td><a href="#" title="<?php echo $Rows["Cpassword"]; ?>">********</a></td>
												</tr>
												<?php } ?>
												</tbody>
											</table>    
											<?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Customer</div>
                                        <?php } ?>
											
											</div>
											 </div>
										</div>
									</div>
					<!-- /widget-content --> 
					
								</div>
							</div>
						 </div>
					</div>
				</div>
			  </div>
		  </div>
	   </div>
	   <?php include("Include/footer.php"); ?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

	 </body>
	</html>
			  