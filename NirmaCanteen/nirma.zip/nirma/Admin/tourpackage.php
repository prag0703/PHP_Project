
<?php
	require("include/sessionchecker.php");
?>

<?php

require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$name = $_POST["p_name"];
		$sdate = $_POST["p_startdate"];
		$edate = $_POST["p_enddate"];
		$pstate = $_POST["p_state"];
		$pcity = $_POST["p_city"];
		$pamount = $_POST["p_amount"];
		$pdiscription = $_POST["p_discription"]; 
		$isactive = $_POST["p_isactive"];	
		$ppaymentterm = $_POST["p_paymentterm"];
		
		$tourimg = $_FILES["tourimg"];
		$Ext = strrchr($tourimg["name"],".");
		$NewImg = date("dmyhmsi").$Ext;
		if($tourimg["name"]!="")
		{
			move_uploaded_file($tourimg["tmp_name"],"upload/".$NewImg);
		}
	
		
		$str = "INSERT INTO tbl_tpackage(p_name,start_date,end_date,state,city,p_amount,discription,tour_img,is_active,payment_term) VALUES('$name','$sdate','$edate','$pstate','$pcity','$pamount','$pdiscription','$NewImg','$isactive','$ppaymentterm')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourpackage.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$name = $_POST["p_name"];
		$sdate = $_POST["p_startdate"];
		$edate = $_POST["p_enddate"];
		$pstate = $_POST["p_state"];
		$pcity = $_POST["p_city"];
		$pamount = $_POST["p_amount"];
		$pdiscription = $_POST["p_discription"]; 
		$isactive = $_POST["p_isactive"];	
		$ppaymentterm = $_POST["p_paymentterm"];
		
		$str = "UPDATE tbl_tpackage SET p_name='$name',start_date='$sdate',end_date='$edate',state='$pstate',city='$pcity',p_amount='$pamount',discription='$pdiscription',tour_img='$tourimg',is_active='$isactive',payment_term='$ppaymentterm'";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourpackage.php?msg=Record Inserted sucessfully");
	}


	if(isset($_GET["delId"]))
		{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_tpackage WHERE tp_id='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:tourpackage.php?msg=Record Deleted sucessfully");
		}

		$selstr = "SELECT * FROM tbl_tpackage";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

		if(isset($_GET["edId"]))
		{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_tpackage WHERE tp_id='$Id'";
			$Edata=mysql_query($str) or die("Error: Insert query problem");	
			$ERows=mysql_fetch_assoc($Edata);
		}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script>
		
			function namevalid()
			{
				var name = /^[a-zA-Z\s-, ]+$/;;
				var val = document.getElementById('p_name');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divname').innerHTML="Please Enter valid name.";
					return false;
				}  
				else
				{
					document.getElementById('divname').innerHTML="";
					return true;
				}  
			}
			
			function pamount()
			{
				var price= /^[1-9]+.[0-9][1-9]$/;
				var val=document.getElementById('p_amount');
				if(price.test(val.value) == false)
				{
					document.getElementById('pno').innerHTML="Enter Amount";
					return false;
				}
				else
				{	
					document.getElementById('pno').innerHTML="";
					return true;
				}
			}
			
			function description()
			{
				var name = /^[a-zA-Z0-9\s-, ]+$/;;
				var val = document.getElementById('p_discription');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divdes').innerHTML="Please Enter Description.";
					return false;
				}  
				else
				{
					document.getElementById('divdes').innerHTML="";
					return true;
				}  
			}
			 
			function paymentterm()
			{
				var name = /^[0-9\,]+$/;;
				var val = document.getElementById('p_paymentterm');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divpay').innerHTML="Please Enter Description.";
					return false;
				}  
				else
				{
					document.getElementById('divpay').innerHTML="";
					return true;
				}  
			}
			 
	</script>
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list"></i>
              				<h3> Tour Package Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
           
           									<?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        	<?php } ?>
                        
           
            <form action="#" method="post">
            	
                
                <table cellpadding="10px">
                                
                <tr>
                <td>Package Name</td>
                <td><input type="text" name="p_name" id="p_name" placeholder="Tour Package Name"  onBlur="namevalid()"<?php if(isset($ERows)) { ?>value="<?php echo $ERows["p_name"]; ?>"<?php } ?> />	</td>
                <td><span id="divname" style="color:#930 !important"> *</span></td>
                </tr>
					
				<tr>
                <td>Start Date</td>
                <td><input type="date" name="p_startdate" id="p_startdate" placeholder="start Date" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["start_date"]; ?>"<?php } ?> onBlur="validdate()" required="required"/></td>
                <td><span id="divname" style="color:#930 !important"> *</span></td>
				</tr>
                
                <tr>
                <td>End Date</td>
                <td><input type="date" name="p_enddate" id="p_enddate" placeholder="End Date" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["end_date"]; ?>"<?php } ?> onBlur="startdate()" required="required"/></td>
                <td><span id="divname" style="color:#930 !important"> *</span></td>
                </tr>
				
                <tr>
                <td>State</td>
                <td>	
				<select name="p_state" value="">
                        
								<option value=" "  <?php if(isset($ERows)) { ?><?php } ?>> Select State</option>
								<option value="Gujarat"  <?php if(isset($ERows)){ if($ERows["state"]=="Gujarat") { ?> selected="selected"<?php } } ?>> Gujarat</option>
								<option value="Maharastra" <?php if(isset($ERows)){ if($ERows["state"]=="Maharastra") { ?> selected="selected"<?php } } ?>>Maharastra</option>
								<option value="Panjab" <?php if(isset($ERows)){ if($ERows["state"]=="Panjab") { ?> selected="selected"<?php } } ?>> Panjab</option>
							 </select>

                 </td>
                 </tr>
                  
                  <tr>
                  <td>City</td>
                  <td>	
					<select name="p_city" value="">
                        <option value=""> Select City</option>
						<option value="Ahmedabad" <?php if(isset($ERows)){ if($ERows["city"]=="Ahmedabad") { ?> selected="selected"<?php } } ?>> Ahmedabad</option>
						<option value="Surat" <?php if(isset($ERows)){ if($ERows["city"]=="Surat") { ?> selected="selected"<?php } } ?>> Surat</option>
						<option value="Rajkot" <?php if(isset($ERows)){ if($ERows["city"]=="Rajkot") { ?> selected="selected"<?php } } ?>> Rajkot</option>
						</select>
                  </td>
                  </tr>
                  
                  <tr>
					<td>Package Amount</td>	
					<td><input type="number" name="p_amount" id="p_amount" onBlur="pamount()" placeholder="Package Amount" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["p_amount"]; ?>"<?php } ?>/></td>
                    <td><span id="pno" style="color:#930 !important"> *</span></td>
				</tr>
                
                <tr>
                <td>Discription	</td>
				<td><textarea name="p_discription" id="p_discription" onBlur="description()" placeholder="Discription">
                <?php if(isset($ERows)) { ?><?php echo $ERows["discription"]; ?><?php } ?>
                </textarea></td>
                <td><span id="divdes" style="color:#930 !important"> *</span></td>
                </tr>
                
                <tr>
                <td> Tour Image</td>
                <td><input type="file" name="tourmimg"/></td>
                </tr>
                
                 <tr>
 					<td>Is Active</td>
                    <td><input type="radio" name="p_isactive" value="yes" <?php if(isset($ERows)){ if($ERows["is_active"] == "yes") { ?> checked="checked" <?php } } ?>/>Yes
                    	<input type="radio" name="p_isactive" value="no" <?php if(isset($ERows)){ if($ERows["is_active"] == "no") { ?> checked="checked" <?php } } ?> />No</td>
                 </tr>    

                <tr>
                <td>Payment Term</td>
                <td><input type="number" name="p_paymentterm" id="p_paymentterm" onBlur="paymentterm()" placeholder="payment Term" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["payment_term"]; ?>"<?php } ?>/></td>
                <td><span id="divpay" style="color:#930 !important"> *</span></td>
				</tr>		
			
            <tr>
            	<td></td>
            	<td><?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
                </td>
            </tr>
            </table>
			</form>
            
            <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Tour Package</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Package Name</th>
                                                <tH>Start Date</tH>
                                                <th>End Date</th>
                                                <th>State</th>
                                                <th>City</th>
                                                <th>Package Amount</th>
                                                <th>Discription </th>
                                                <th>Tour Image</th>
                                                <th>Is Active</th>
                                                <th>Payment Term</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["tp_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["tp_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["p_name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["tp_id"]; ?></td>
                                                <td><?php echo $Rows["p_name"]; ?></td>
                                                <td><?php echo $Rows["start_date"]; ?></td>
                                                <td><?php echo $Rows["end_date"]; ?></td>
                                                <td><?php echo $Rows["state"]; ?></td>
                                                <td><?php echo $Rows["city"]; ?></td>
                                                <td><?php echo $Rows["p_amount"]; ?></td>
                                                <td><?php echo $Rows["discription"]; ?></td>
                                                <td><?php echo $Rows["tour_img"]; ?></td>
                                                <td><?php echo $Rows["is_active"]; ?></td>
                                                <td><?php echo $Rows["payment_term"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Admin</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

 </body>
</html>
          