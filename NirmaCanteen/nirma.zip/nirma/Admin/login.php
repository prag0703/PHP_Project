<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title> Nirma Canteen Admin</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/pages/signin.css" rel="stylesheet" type="text/css">

</head>

<body>
	
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.php">
				Nirma Canteen				
			</a>		
			
			
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

<div class="ccontainer">

<div class="row">

<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-user"></i>
              				<h3 align="center"> Login	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget-container" align="center">
                				
                 					
                                    	<h1 class="ccontainer">Admin Login</h1>
            							<form action="deshboad.php" method="post">
                                        <table class="ccontainer" align="center">
                                        
                                       
                                        	<tr>
                                            <td> Username</td>
                                            <td><input type="text" name="uname" id="uname"></td>
                                            </tr>
                                            
                                            <tr>
                                            <td> Password</td>
                                            <td><input type="password" name="password" id="password"></td>
                                            </tr>
                                           
                                            <tr>
            								<td></td>
                                            <td><input type="submit" name="submit" class="btn btn-primary"></td>
            								
            								</tr>
                                            
                                            
                                        </table>
          
								</form>

                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>



</div>
</div>

  
    
    
  
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>



</body>


</html>
