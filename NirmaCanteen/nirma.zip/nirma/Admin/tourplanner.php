
<?php /*?><?php
	require("include/sessionchecker.php");
?>

<?php
	
	require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$name = $_POST["tp_name"];
		$address = $_POST["tp_address"];
		$state = $_POST["tp_state"];
		$city = $_POST["tp_city"];
		$zipcode = $_POST["tp_zipcode"];
		$contact = $_POST["tp_contact"];
		$email = $_POST["tp_email"];
		$password = $_POST["tp_password"];
		$isactive = $_POST["isactive"];
		
		$str = "INSERT INTO tbl_tplanner(name,address,state,city,zipcode,contact,email_id,password,is_active) VALUES('$name','$address','$state','$city','$zipcode','$contact','$email','$password','$isactive')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourplanner.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$name = $_POST["tp_name"];
		$address = $_POST["tp_address"];
		$state = $_POST["tp_state"];
		$city = $_POST["tp_city"];
		$zipcode = $_POST["tp_zipcode"];
		$contact = $_POST["tp_contact"];
		$email = $_POST["tp_email"];
		$password = $_POST["tp_password"];
		$isactive = $_POST["isactive"];
		
		$str = "UPDATE tbl_tplanner SET name='$name',address='$address',state='$state',city='$city',zipcode='$zipcode',contact='$contact',email_id='$email',password='$password',is_active='$isactive'";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:tourplanner.php?msg=Updated Inserted sucessfully");
	}
	
		if(isset($_GET["delId"]))
			{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_tplanner WHERE tp_id='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:tourplanner.php?msg=Record Deleted sucessfully");
			}
		
		$selstr = "SELECT * FROM tbl_tplanner";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);

		if(isset($_GET["edId"]))
			{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_tplanner WHERE tp_id='$Id'";
			$Edata=mysql_query($str) or die("Error: Insert query problem");	
			$ERows=mysql_fetch_assoc($Edata);
			}
	
	?><?php */?>
	
	
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Nirma Canteen Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    
    <script>
		
			function namevalid()
			{
				var name = /^[a-zA-Z\s-, ]+$/;;
				var val = document.getElementById('tp_name');
				if (name.test(val.value) == false) 
				{
					document.getElementById('divname').innerHTML="Please Enter valid name.";
					return false;
				}  
				else
				{
					document.getElementById('divname').innerHTML="";
					return true;
				}  
			} 
 			
			function address(val)
			{
				if(val== "")
				{
					document.getElementById('tp_address').innerHTML="Must enter address..";
					return false;
				}
				else
				{	
					document.getElementById('tp_address').innerHTML="";
					return true;
				}
			}
			
			function state(val)
			{
				if(val== "")
				{
					document.getElementById('divcity').innerHTML="Fill the data..";
					return false;
				}
				else
				{	
					document.getElementById('divcity').innerHTML="";
					return true;
				}
				
			}

			function pincodes()
			{
				var mob = /^[0-9]{6}$/;
				var val = document.getElementById('tp_zipcode');
				if (mob.test(val.value) == false) 
					{
						//	alert(val.value);
						document.getElementById('divnum1').innerHTML="Please enter valid Zipcode.";
						return false;
					}  
			  else
					{
						document.getElementById('divnum1').innerHTML="";
						return true;
					}  
			} 
			
			function mobilenum()
			{
				var mob = /^[1-9]{1}[0-9]{9}$/;
				var val = document.getElementById('tp_contact');
				if (mob.test(val.value) == false) 
					{
						document.getElementById('divnum').innerHTML="Please enter valid mobile number.";
						return false;
					}  
			  else
					{
						document.getElementById('divnum').innerHTML="";
						return true;
					}  
			} 
			
			function validmail(val)   
			{  
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
				{  
					document.getElementById('divmail').innerHTML=""; 
					return true;	
				}  
				else
				{
					document.getElementById('divmail').innerHTML="Please enter valid email";  
					return false;
				}
			} 

			function validmail1(val)   
			{  
				if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
				{  
					document.getElementById('divmail1').innerHTML=""; 
					return true;	
				}  
				else
				{
					document.getElementById('divmail1').innerHTML="Please enter valid id";  
					return false;
				}
			} 

		</script>
        
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list"></i>
              				<h3> Tour Planner Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
            				
							
							<?php if(isset($_GET["msg"])){?>
							<div class="alert alert-success">
							<?php echo $_GET["msg"]; ?>
							</div> 
							<?php } ?>			
           
           
           
           <?php /*?><form action="#" method="post">
            
            
            
            <table cellpadding="10px">    
            
           
             <tr>
             	<td>Planer Name</td>	
			 	<td><input type="text" name="tp_name" id="tp_name" placeholder="Name of customer" onBlur="namevalid()"<?php if(isset($ERows)) { ?>value="<?php echo $ERows["name"]; ?>"<?php } ?> onBlur="namevalid()"/></td>
                <td><span id="divname" style="color:#930 !important"> *</span></td>
			 </tr>
                
             <tr>
             	<td>Address</td>
             	<td><textarea id="address" name="tp_address" id="tp_address" onBlur="address()" placeholder="" >
                <?php if(isset($ERows)) { ?><?php echo $ERows["address"]; ?><?php } ?>
                </textarea></td>
                <td><span id="divname" style="color:#930 !important"> *</span></td>
             </tr>
			
            <tr>
            <td>State</td>
            <td>
            		<select name="tp_state">
                    <option value=" "  <?php if(isset($ERows)) { ?><?php } ?>> Select State</option>
								<option value="Gujarat"  <?php if(isset($ERows)){ if($ERows["state"]=="Gujarat") { ?> selected="selected"<?php } } ?>> Gujarat</option>
								<option value="Maharastra" <?php if(isset($ERows)){ if($ERows["state"]=="Maharastra") { ?> selected="selected"<?php } } ?>>Maharastra</option>
								<option value="Panjab" <?php if(isset($ERows)){ if($ERows["state"]=="Panjab") { ?> selected="selected"<?php } } ?>> Panjab</option>
                    </select>
            </td>
            </tr>
            <tr>
            <td>City</td>
            	<td>	
					<select name="tp_city">
                    <option value=""> Select City</option>
						<option value="Ahmedabad" <?php if(isset($ERows)){ if($ERows["city"]=="Ahmedabad") { ?> selected="selected"<?php } } ?>> Ahmedabad</option>
						<option value="Surat" <?php if(isset($ERows)){ if($ERows["city"]=="Surat") { ?> selected="selected"<?php } } ?>> Surat</option>
						<option value="Rajkot" <?php if(isset($ERows)){ if($ERows["city"]=="Rajkot") { ?> selected="selected"<?php } } ?>> Rajkot</option>
                    </select>
            	</td>
            </tr>
            
            <tr>
            <td>Zipcode</td>
            <td><input type="number" name="tp_zipcode" id="tp_zipcode" onBlur="pincodes();" placeholder="zipcode" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["zipcode"]; ?>"<?php } ?>  /></td>
            <td><span id="divnum1" style="color:#930 !important"> *</span></td>
            </tr>
             
             <tr>
             <td>Contact</td>	
			 <td><input type="number" name="tp_contact" id="tp_contact" onBlur="mobilenum()"  placeholder="Contact" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["contact"]; ?>"<?php } ?> /></td>
             <td><span id="divnum" style="color:#930 !important"> *</span></td>
             </tr>
			
            <tr>
            <td>Email</td>
			<td><input type="email" name="tp_email" id="tp_email" placeholder="Email ID" onBlur="validmail()" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["email_id"]; ?>"<?php } ?>/></td>
            <td><span id="divmail" style="color:#930 !important"> *</span></td>
            </tr>
			
            <tr>
				<td>Password</td>
				<td><input type="password" name="tp_password" placeholder="Password" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["password"]; ?>"<?php } ?>/></td>
            </tr>
			
            <tr>
            <td>Is Active</td>
			<td><input type="radio" name="tp_isactive" value="yes" <?php if(isset($ERows)){ if($ERows["is_active"] == "yes") { ?> checked="checked" <?php } } ?>/>Yes
            <input type="radio" name="tp_isactive" value="no" <?php if(isset($ERows)){ if($ERows["is_active"] == "no") { ?> checked="checked" <?php } } ?>/>No
            </td>
            </tr>
            
            <tr>
            	<td></td>
            	<td><?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
               </td>
            </tr>
            
            </table>
			</form>
            <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Tour Planner</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Planner Name</th>
                                                <th>Address</th>
                                                <th>State</th>
                                                <th>City</th>
                                                <th>Zipcode</th>
                                                <tH>Contact</tH>
                                                <th>Email Id</th>
                                                <th>Password</th>
                                                <th>Register Date</th>
                                                <th>Is Active</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["tp_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["tp_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["name"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["tp_id"]; ?></td>
                                                <td><?php echo $Rows["name"]; ?></td>
                                                <td><?php echo $Rows["address"]; ?></td>
                                                <td><?php echo $Rows["state"]; ?></td>
                                                <td><?php echo $Rows["city"]; ?></td>
                                                <td><?php echo $Rows["zipcode"]; ?></td>
                                                <td><?php echo $Rows["contact"]; ?></td>
                                                <td><?php echo $Rows["email_id"]; ?></td>
                                                <td><a href="#" title="<?php echo $Rows["password"]; ?>">********</a></td>
                                                <td><?php echo $Rows["register_date"]; ?></td>
                                                <td><?php echo $Rows["is_active"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record in Tour Planner</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                        </div>
                                         </div><?php */?>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
   <script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

 </body>
</html>
          