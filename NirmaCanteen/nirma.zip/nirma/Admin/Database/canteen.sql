-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 09, 2016 at 11:25 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `canteen`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `a_id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `contact` int(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `login_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`a_id`, `name`, `contact`, `email_id`, `login_id`, `password`, `register_date`) VALUES
(5, 'Kaushik', 2147483647, 'abc@gmail.com', 'abc@gmail.com', 'admin', '2016-02-27 05:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `CatId` int(11) NOT NULL AUTO_INCREMENT,
  `CatName` varchar(50) NOT NULL,
  `IsActive` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`CatId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`CatId`, `CatName`, `IsActive`) VALUES
(1, 'Kaushik Patel', '0'),
(2, 'kaushik', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `CustId` int(11) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Emailid` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Cpassword` varchar(50) NOT NULL,
  PRIMARY KEY (`CustId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`CustId`, `Fname`, `Lname`, `Address`, `Contact`, `Gender`, `Emailid`, `Password`, `Cpassword`) VALUES
(1, 'Kaushik', 'Makholiya', 'Anyrhing', '8238007776', 'Male', 'Admin@gmail.com', '123', '123'),
(2, 'Kaushik', 'Patel', 'Anything ', '8238007776', 'male', 'abc@gmail.com', '1234', '1234'),
(11, 'Kaushik', 'Makholiya', 'sidhasasr', '9726456102', 'on', 'kp72835@gmail.com', '', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_foodmenu`
--

CREATE TABLE IF NOT EXISTS `tbl_foodmenu` (
  `FoodId` int(10) NOT NULL AUTO_INCREMENT,
  `CatId` int(10) NOT NULL,
  `FoodName` varchar(50) NOT NULL,
  `Amount` int(50) NOT NULL,
  `IsAvailable` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`FoodId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_foodmenu`
--

INSERT INTO `tbl_foodmenu` (`FoodId`, `CatId`, `FoodName`, `Amount`, `IsAvailable`) VALUES
(1, 0, 'FOOD NAME', 132, '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `OrderId` int(10) NOT NULL AUTO_INCREMENT,
  `FoodId` int(10) NOT NULL,
  `Quantity` decimal(10,0) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`OrderId`, `FoodId`, `Quantity`, `TotalAmount`) VALUES
(1, 0, '1', '123.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE IF NOT EXISTS `tbl_staff` (
  `StaffId` int(10) NOT NULL AUTO_INCREMENT,
  `StaffName` varchar(50) NOT NULL,
  `StaffDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`StaffId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_staff`
--

INSERT INTO `tbl_staff` (`StaffId`, `StaffName`, `StaffDateTime`) VALUES
(1, 'Kaushik Patel', '2016-10-09 11:13:34');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
