<script>
function namevalid()
{
	var name = /^[a-zA-Z\s-, ]+$/;;
    var val = document.getElementById('name');
    if (name.test(val.value) == false) 
		{
			document.getElementById('divname').innerHTML="Please enter name.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divname').innerHTML="";
			return true;
        }  
} 
 
function mobilenum()
{
	var mob = /^[1-9]{1}[0-9]{9}$/;
    var val = document.getElementsByName('admincontact');
    if (mob.test(val.value) == false) 
		{
			document.getElementById('divnum').innerHTML="Please enter valid mobile number.";
			return false;
        }  
  else
		{
  	    	document.getElementById('divnum').innerHTML="";
			return true;
        }  
} 

function validmail(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail').innerHTML="Please enter valid email";  
		return false;
  	}
} 

function validmail1(val)   
{  
 	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(val))  
  	{  
   		document.getElementById('divmail1').innerHTML=""; 
		return true;	
  	}  
  	else
  	{
    	document.getElementById('divmail1').innerHTML="Please enter valid id";  
		return false;
  	}
} 


</script>