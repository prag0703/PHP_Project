
<?php
	require("include/sessionchecker.php");
?>


<?php

require("dbConfig/dbConfig.php");
	
	if(isset($_POST["Submit"]))
	{
		$custmrid = $_POST["vr_custmrid"];
		$vehicleid = $_POST["vr_vehicleid"];
		$tdate = $_POST["vr_tdate"];
		$rdate = $_POST["vr_rdate"];
		$estimatekm = $_POST["vr_estimatekm"];
		$comment = $_POST["vr_comment"];
		$isapprove = $_POST["isapprove"]; 	
		
		$str = "INSERT INTO tbl_vrequest(customer_id,v_id,travel_date,return_date,estimate_km,comment,is_approve) VALUES('$custmrid','$vehicleid','$tdate','$rdate','$estimatekm','$comment','$isapprove')";
		
		mysql_query($str) or die("Error: Insert query problem");
		header("location:vehiclerequest.php?msg=Record Inserted sucessfully");
	}
	
	if(isset($_POST["editbtn"]))
	{
		$custmrid = $_POST["vr_custmrid"];
		$vehicleid = $_POST["vr_vehicleid"];
		$tdate = $_POST["vr_tdate"];
		$rdate = $_POST["vr_rdate"];
		$estimatekm = $_POST["vr_estimatekm"];
		$comment = $_POST["vr_comment"];
		$isapprove = $_POST["isapprove"]; 	
		
		$str = "UPDATE tbl_vrequest SET customer_id='$custmrid',v_id='$vehicleid',travel_date='$tdate',return_date='$rdate',estimate_km='$estimatekm',comment='$comment',is_approve='$isapprove'";
		mysql_query($str) or die("Error: Insert query problem");
		header("location:vehiclerequest.php?msg=Record Updated sucessfully");
	}

		$selstr = "SELECT * FROM tbl_vrequest";
		$Data = mysql_query($selstr) or die("Error: Select Query problem");
		$num = mysql_num_rows($Data);
		
		if(isset($_GET["delId"]))
			{
			$Id = base64_decode($_GET["delId"]);
			$str = "DELETE FROM tbl_vrequest WHERE vr_id='$Id'";
			mysql_query($str) or die("Error: Insert query problem");	
			header("location:vehiclerequest.php?msg=Record Deleted sucessfully");
			}

		if(isset($_GET["edId"]))
			{
			$Id = base64_decode($_GET["edId"]);
			$str = "SELECT * FROM tbl_vrequest WHERE vr_id='$Id'";
			$Edata=mysql_query($str) or die("Error: query problem");	
			$ERows=mysql_fetch_assoc($Edata);
			}

	

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Vehicle Request Details</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600"
        rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<?php include("Include/header.php"); ?>
<div class="main">
	<div class="main-inner">
    	<div class="container">
      		<div class="row">
        		<div class="span12">
          			<div class="widget widget-nopad">
            			<div class="widget-header"> <i class="icon-list"></i>
              				<h3> Vehicle Request Details	</h3>
            			</div>
            <!-- /widget-header -->
            			<div class="widget-content">
              				<div class="widget big-stats-container">
                				<div class="widget-content">
                 					<div id="big_stats" class="cf">
                                    	<div class="stats" align="center">
            							
                                        <?php if(isset($_GET["msg"])){?>
                                        	<div class="alert alert-success">
                                            <?php echo $_GET["msg"]; ?>
                                            </div> 
                                        <?php } ?>
           
           		<form action="#" method="post">
            
            	<table cellpadding="10px">    
            <tr>
                <td>Customer ID</td>
              	<td><input type="text" name="vr_custmrid" placeholder="Enter Customer Id" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["customer_id"]; ?>"<?php } ?>/></td>									
            </tr>
                
             <tr>	
               	<td>Vehicle ID</td>
               	<td><input type="text" name="vr_vehicleid" placeholder="Enter Vehicle Id" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["v_id"]; ?>"<?php } ?>/></td>
            </tr>
            
            
            <tr>
            	<td>Travel Date</td>
				<td><input type="date" name="vr_tdate" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["travel_date"]; ?>"<?php } ?> /></td>
			</tr>
                    
            <tr>
				<td>Return Date</td>
				<td><input type="date" name="vr_rdate" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["return_date"]; ?>"<?php } ?> /></td>
			</tr>
                
            <tr>
				<td>Estimate KM</td>
				<td><input type="number" name="vr_estimatekm" placeholder="Estimate KM" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["estimate_km"]; ?>"<?php } ?>/></td>
			</tr>
            
            <tr>
				<td>Comment</td>
				<td><input type="text" name="vr_comment" placeholder="Enter Comment" <?php if(isset($ERows)) { ?>value="<?php echo $ERows["comment"]; ?>"<?php } ?>/></td>
			</tr>
                
            <tr>
                <td>Is Approve</td>
				<td><input type="radio" name="isapprove" value="yes" <?php if(isset($ERows)){ if($ERows["is_approve"] == "yes") { ?> checked="checked" <?php } } ?>/>Yes
            		<input type="radio" name="isapprove" value="no" <?php if(isset($ERows)){ if($ERows["is_approve"] == "no") { ?> checked="checked" <?php } } ?>/>No
            	</td>
           	</tr>
                
            <tr>
            	<td></td>
            	<td>
							<?php if(isset($ERows)){ ?>
                    		<input type="submit" name="editbtn" value="Update" class="btn-primary btn-large" >
                    		<input type="hidden" name="edId" value="<?php echo $Id; ?>">
                    		<?php } else { ?>
                    		<input type="submit" name="Submit" class="btn-primary btn-large" />
                    		<?php } ?>
</td>
            </tr>
            </table>
			</form>
            
            <div class="widget widget-table action-table">
                                        <div class="widget-header"> <i class="icon-th-list"></i>
                                          <h3>Vehicle Request</h3>
                                        </div>
                                        <!-- /widget-header -->
                                        <div class="widget-content">
                                       
                               			<?php if($num > 0) { ?>
                                          <table class="table table-striped table-bordered">
                                            <thead>
                             	           <tr>
                                           		<th>ACTIONS</th>
                                           		<th>Id</th>
                                                <th>Customer ID</th>
                                                <tH>Vehicle ID</tH>
                                                <th>Request Date</th>
                                                <th>Travel Date</th>
                                                <th>Return Date</th>
                                                <th>Estimated Km</th>
                                                <th>Comment</th>
                                                <th>Is Approve</th>
                                        	</tr>
                                            </thead>
                                            <tbody>
                                            <?php while($Rows = mysql_fetch_array($Data))
											{
											?>
                                            <tr>
                                            	<td class="td-actions"><a href="?edId=<?php echo base64_encode($Rows["vr_id"]); ?>" class="btn btn-small btn-success"><i class="btn-icon-only icon-edit"> </i></a> <a href="?delId=<?php echo base64_encode($Rows["vr_id"]); ?>" class="btn btn-danger btn-small" onClick="return confirmMe('Are you sure to Delete : <?php echo $Rows["customer_id"]; ?> ?')"><i class="btn-icon-only icon-trash"> </i></a></td>
                                            	<td><?php echo $Rows["vr_id"]; ?></td>
                                                <td><?php echo $Rows["customer_id"]; ?></td>
                                                <td><?php echo $Rows["v_id"]; ?></td>
                                                <td><?php echo $Rows["request_date"]; ?></td>
                                                <td><?php echo $Rows["travel_date"]; ?></td>
                                                <td><?php echo $Rows["return_date"]; ?></td>
                                                <td><?php echo $Rows["estimate_km"]; ?></td>
                                                <td><?php echo $Rows["comment"]; ?></td>
                                                <td><?php echo $Rows["is_approve"]; ?></td>
                                            </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>    
                                        <?php } else { ?>
                                        <div class="alert alert-danger">There is no Record</div>
                                        <?php } ?>
                                        </div>
                                        </div>
                                        
                                        </div>
                                         </div>
                  					</div>
                				</div>
                <!-- /widget-content --> 
                
             				</div>
            			</div>
         			 </div>
          		</div>
          	</div>
          </div>
      </div>
   </div>
   <?php include("Include/footer.php"); ?>
   <script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

   </body>
   </html>